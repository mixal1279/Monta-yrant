// tickets/ticketManager.js
// Tworzy prywatny kanał-ticket dla zamówienia, pilnuje zasady "jeden aktywny
// ticket na użytkownika" oraz buduje przyciski do zarządzania statusem zamówienia.

const {
  ChannelType,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { getDb } = require('../database/db');
const { getConfig } = require('../config/config');
const { orderTicketEmbed } = require('../utils/embeds');
const { logEvent } = require('../utils/logger');

// Sprawdza, czy użytkownik ma już aktywny ticket (zamówienie z przypisanym
// kanałem, którego status nie jest finalny).
function getActiveOrderForUser(guildId, userId) {
  const db = getDb();
  return db
    .prepare(
      `SELECT * FROM orders
       WHERE guild_id = ? AND user_id = ? AND ticket_channel_id IS NOT NULL
       AND status NOT IN ('completed', 'cancelled', 'delivered')
       ORDER BY id DESC LIMIT 1`
    )
    .get(guildId, userId);
}

function statusButtonsRow(orderId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`ticket_status_paid_${orderId}`)
      .setLabel('Opłacone')
      .setStyle(ButtonStyle.Success)
      .setEmoji('💰'),
    new ButtonBuilder()
      .setCustomId(`ticket_status_in_progress_${orderId}`)
      .setLabel('W trakcie realizacji')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('🔧'),
    new ButtonBuilder()
      .setCustomId(`ticket_status_waiting_for_materials_${orderId}`)
      .setLabel('Czeka na materiały')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('⏳'),
    new ButtonBuilder()
      .setCustomId(`ticket_status_delivered_${orderId}`)
      .setLabel('Dostarczone')
      .setStyle(ButtonStyle.Success)
      .setEmoji('📦'),
    new ButtonBuilder()
      .setCustomId(`ticket_status_cancelled_${orderId}`)
      .setLabel('Anuluj')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('❌')
  );
}

function closeTicketButtonRow(orderId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`ticket_close_${orderId}`)
      .setLabel('Zamknij ticket')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('🔒')
  );
}

async function createTicketForOrder(client, guild, order) {
  const cfg = getConfig(guild.id);
  if (!cfg || !cfg.ticket_category_id) {
    throw new Error('Kategoria ticketów nie jest skonfigurowana — użyj /setup.');
  }

  const existing = getActiveOrderForUser(guild.id, order.user_id);
  if (existing && existing.id !== order.id) {
    throw new Error('Masz już aktywny ticket. Zakończ go przed złożeniem kolejnego zamówienia.');
  }

  const overwrites = [
    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id: order.user_id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
      ],
    },
    { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
  ];

  if (cfg.staff_role_id) {
    overwrites.push({
      id: cfg.staff_role_id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
      ],
    });
  }
  if (cfg.admin_role_id) {
    overwrites.push({
      id: cfg.admin_role_id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
      ],
    });
  }

  const channel = await guild.channels.create({
    name: `zamowienie-${order.id}`,
    type: ChannelType.GuildText,
    parent: cfg.ticket_category_id,
    permissionOverwrites: overwrites,
    topic: `Zamówienie #${order.id} — klient <@${order.user_id}>`,
  });

  const db = getDb();
  db.prepare('UPDATE orders SET ticket_channel_id = ?, updated_at = ? WHERE id = ?').run(
    channel.id,
    new Date().toISOString(),
    order.id
  );
  const updatedOrder = db.prepare('SELECT * FROM orders WHERE id = ?').get(order.id);

  const staffPing = cfg.staff_role_id ? `<@&${cfg.staff_role_id}>` : '';
  await channel.send({
    content: `${staffPing} Nowy ticket — <@${order.user_id}> zgłasza płatność za zamówienie #${order.id}.`,
    embeds: [orderTicketEmbed(updatedOrder)],
    components: [statusButtonsRow(order.id), closeTicketButtonRow(order.id)],
  });

  await logEvent(client, guild.id, 'zamowienie', `Utworzono ticket dla zamówienia #${order.id} (<@${order.user_id}>).`);

  return channel;
}

module.exports = { createTicketForOrder, getActiveOrderForUser, statusButtonsRow, closeTicketButtonRow };
