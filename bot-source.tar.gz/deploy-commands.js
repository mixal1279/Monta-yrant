// deploy-commands.js
// Rejestruje komendy slash w Discordzie. Uruchom raz po każdej zmianie
// definicji komend: `npm run deploy`.
//
// Jeśli w .env ustawione jest GUILD_ID — rejestracja jest natychmiastowa,
// ale tylko na tym jednym serwerze (dobre do testów).
// Jeśli GUILD_ID jest puste — rejestracja globalna (propagacja do ok. 1h).

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID;

if (!token || !clientId) {
  console.error('❌ Brak DISCORD_TOKEN lub CLIENT_ID w pliku .env.');
  process.exit(1);
}

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter((f) => ['setup.js', 'panel.js'].includes(f));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  if (command?.data) commands.push(command.data.toJSON());
}

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    console.log(`🚀 Rejestruję ${commands.length} komend...`);

    if (guildId) {
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
      console.log(`✅ Komendy zarejestrowane na serwerze ${guildId} (natychmiast aktywne).`);
    } else {
      await rest.put(Routes.applicationCommands(clientId), { body: commands });
      console.log('✅ Komendy zarejestrowane globalnie (propagacja do ok. 1h).');
    }
  } catch (err) {
    console.error('❌ Błąd rejestracji komend:', err);
  }
})();
