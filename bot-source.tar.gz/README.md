# MontaŻyrant — Web Orders + Lightweight Discord Notifier

## Architektura
Strona jest głównym panelem obsługi: klient składa zamówienie, płaci i śledzi status. Discord służy głównie do powiadomień oraz jednorazowej konfiguracji kanałów/roli.

```text
Klient → strona → Express API → SQLite
                         ↓
                  Discord notifier
                         ↓
                  kanał + DM klienta
```

### Cel: VPS 256 MB RAM
- jeden proces Node.js
- Express + discord.js + better-sqlite3
- SQLite zamiast zewnętrznej bazy
- frontend statyczny poza VPS
- bot nie ładuje starego flow zamówień, ticketów, eksportów i interakcji
- tylko komendy `/setup` i `/panel`

## Wymagania

- **Node.js 18–22 LTS** (zalecane: Node 20 LTS)
- **npm ≥ 9**
- build tools dla native modules: `gcc`, `g++`, `python3`, `make`
  - Ubuntu/Debian: `apt install build-essential python3`
  - Na Pterodactyl: użyj obrazu `ghcr.io/pterodactyl/yolks:nodejs_20`

> ⚠️ **Node 24** — prebuildy `better-sqlite3` mogą nie pasować do V8 z Node 24.  
> `.npmrc` w tym repo wymusza kompilację ze źródeł (`better-sqlite3_from_source=true`),  
> co wymaga dostępnych build tools w kontenerze.  
> Jeśli kontener jest slim/alpine bez build tools — użyj Node 20 LTS.

## Uruchomienie

```bash
npm install
npm start
```

**Pterodactyl startup command:**
```bash
npm install && node index.js
```

`.env` minimum:
```env
DISCORD_TOKEN=
CLIENT_ID=
GUILD_ID=
SITE_URL=https://montazyrant.pl
WEBHOOK_PORT=8443
SITE_COOKIE_DOMAIN=.montazyrant.pl
```

Do logowania Discord OAuth potrzebne są także ustawienia klienta OAuth używane przez `utils/discordAuth.js`.

## Panel
Po wdrożeniu statycznych plików otwórz:
`https://montazyrant.pl/panel.html`

Dostęp mają Administratorzy oraz osoby z `staff_role_id` / `admin_role_id` ustawionymi przez `/setup`.

Panel obsługuje:
- listę i filtrowanie zamówień,
- podgląd szczegółów,
- zmianę statusu,
- powiadomienie kanału Discord,
- DM klienta o zmianie statusu.

## Discord
`/setup` służy tylko do konfiguracji kanałów/roli.
`/panel` daje staffowi szybki link do panelu WWW.

Stare komendy i ticket-flow pozostają w archiwum projektu, ale nie są ładowane przez proces produkcyjny. Dzięki temu ich zależności i obsługa interakcji nie obciążają procesu.

## Działalność nierejestrowana — ważne przed publikacją

MontaŻyrant może być opisany w dokumentach jako działalność nierejestrowana prowadzona przez osobę fizyczną, a nie jako spółka lub firma wpisana do CEIDG. Przed rozpoczęciem sprzedaży konsumenckiej na odległość uzupełnij w `regulamin.html`, `privacy.html` i `odstapienie.html` rzeczywisty adres przedsiębiorstwa oraz numer telefonu. Jeżeli posiadasz NIP, możesz go również wskazać. Nie wpisuj fikcyjnych danych.
