// handlers/reviewFlow.js
// Po kliknięciu liczby gwiazdek otwiera modal na komentarz, zapisuje opinię,
// publikuje ją na kanale opinii i oznacza zamówienie jako "completed".

const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder } = require('discord.js');
const { getDb } = require('../database/db');
const { getConfig } = require('../config/config');
const { logEvent } = require('../utils/logger');
const { BRAND_COLOR } = require('../utils/embeds');

// Tymczasowo trzymamy wybraną ocenę między kliknięciem gwiazdek a wysłaniem modala z komentarzem.
const pendingRatings = new Map(); // key: `${userId}_${orderId}` -> rating

async function handleRatingButton(interaction, rating, orderId) {
  const order = getDb().prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  if (!order) return interaction.reply({ content: 'Nie znaleziono zamówienia.', ephemeral: true });
  if (order.user_id !== interaction.user.id) {
    return interaction.reply({ content: 'Tylko klient zamówienia może je ocenić.', ephemeral: true });
  }

  pendingRatings.set(`${interaction.user.id}_${orderId}`, rating);

  const modal = new ModalBuilder()
    .setCustomId(`review_comment_modal_${orderId}`)
    .setTitle(`Ocena: ${'⭐'.repeat(rating)}`);

  const commentInput = new TextInputBuilder()
    .setCustomId('comment')
    .setLabel('Komentarz (opcjonalnie)')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(500);

  modal.addComponents(new ActionRowBuilder().addComponents(commentInput));
  await interaction.showModal(modal);
}

async function handleReviewCommentSubmit(interaction, orderId) {
  const key = `${interaction.user.id}_${orderId}`;
  const rating = pendingRatings.get(key);
  pendingRatings.delete(key);

  if (!rating) {
    return interaction.reply({
      content: 'Nie znaleziono Twojej oceny — spróbuj kliknąć gwiazdki ponownie.',
      ephemeral: true,
    });
  }

  const order = getDb().prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  if (!order) return interaction.reply({ content: 'Nie znaleziono zamówienia.', ephemeral: true });

  const comment = interaction.fields.getTextInputValue('comment').trim() || null;
  const now = new Date().toISOString();
  const db = getDb();

  db.prepare(
    `INSERT INTO reviews (order_id, user_id, package_name, game, rating, comment, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(orderId, interaction.user.id, order.package_name, order.game, rating, comment, now);

  db.prepare(`UPDATE orders SET status = 'completed', updated_at = ? WHERE id = ?`).run(now, orderId);

  await interaction.reply({ content: `✅ Dziękuję za ocenę (${'⭐'.repeat(rating)})! Zamówienie zostało zamknięte.` });

  const cfg = getConfig(interaction.guildId);
  if (cfg && cfg.reviews_channel_id) {
    const channel = await interaction.guild.channels.fetch(cfg.reviews_channel_id).catch(() => null);
    if (channel) {
      const embed = new EmbedBuilder()
        .setColor(BRAND_COLOR)
        .setTitle(`${'⭐'.repeat(rating)}${'☆'.repeat(5 - rating)} Nowa opinia`)
        .addFields(
          { name: 'Klient', value: `<@${interaction.user.id}>`, inline: true },
          { name: 'Pakiet', value: order.package_name, inline: true },
          { name: 'Gra', value: order.game || '—', inline: true }
        );
      if (comment) embed.addFields({ name: 'Komentarz', value: comment });
      await channel.send({ embeds: [embed] }).catch(() => {});
    }
  }

  await logEvent(
    interaction.client,
    interaction.guildId,
    'ukonczenie',
    `Zamówienie #${orderId} zakończone — ocena ${rating}/5 od <@${interaction.user.id}>.`
  );
}

module.exports = { handleRatingButton, handleReviewCommentSubmit };
