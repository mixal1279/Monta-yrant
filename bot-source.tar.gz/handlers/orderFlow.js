// handlers/orderFlow.js
// Obsługuje wszystkie interakcje (select menu / button / modal) związane
// z krokami składania zamówienia rozpoczętego komendą /zamowienie.
// Stan między krokami trzymany jest w utils/sessionStore.js.

const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');

const crypto = require('crypto');
const { getSession, updateSession, clearSession } = require('../utils/sessionStore');
const { getDb } = require('../database/db');
const { getConfig } = require('../config/config');
const { calculateTotal, getAllPackageOptions, prices } = require('../utils/pricing');
const { orderSummaryEmbed, BRAND_COLOR } = require('../utils/embeds');
const { logEvent } = require('../utils/logger');
const { EmbedBuilder } = require('discord.js');

const URL_REGEX = /^https?:\/\/.+/i;

function expiredSessionReply() {
  return {
    content: 'Sesja zamówienia wygasła lub nie istnieje. Użyj ponownie `/zamowienie`, aby zacząć od nowa.',
    embeds: [],
    components: [],
  };
}

// ---------- KROK 1: pakiet -> KROK 2: dodatki ----------
async function handlePackageSelect(interaction) {
  const session = getSession(interaction.user.id);
  if (!session) return interaction.update(expiredSessionReply());

  const value = interaction.values[0];
  const options = getAllPackageOptions();
  const chosen = options.find((o) => o.value === value);

  updateSession(interaction.user.id, { packageKey: value, isBulk: chosen.isBulk });

  const addonOptions = [
    { label: 'Brak dodatków', value: 'none', description: 'Pomiń ten krok' },
    ...Object.values(prices.addons).map((a) => ({
      label: `${a.name} (+${a.price} zł)`,
      value: a.key,
    })),
  ];

  const menu = new StringSelectMenuBuilder()
    .setCustomId('order_addons_select')
    .setPlaceholder('Wybierz dodatki (lub "Brak dodatków")')
    .setMinValues(1)
    .setMaxValues(addonOptions.length)
    .addOptions(addonOptions);

  await interaction.update({
    content: `**Krok 2/5 — Wybierz dodatki:**`,
    components: [new ActionRowBuilder().addComponents(menu)],
  });
}

// ---------- KROK 2: dodatki -> KROK 3: gra ----------
async function handleAddonsSelect(interaction) {
  const session = getSession(interaction.user.id);
  if (!session) return interaction.update(expiredSessionReply());

  const values = interaction.values.includes('none') ? [] : interaction.values;
  updateSession(interaction.user.id, { addons: values });

  const menu = new StringSelectMenuBuilder()
    .setCustomId('order_game_select')
    .setPlaceholder('Wybierz grę')
    .addOptions(prices.games.map((g) => ({ label: g, value: g })));

  await interaction.update({
    content: '**Krok 3/5 — Wybierz grę:**',
    components: [new ActionRowBuilder().addComponents(menu)],
  });
}

// ---------- KROK 3: gra -> KROK 4: źródło materiałów ----------
async function handleGameSelect(interaction) {
  const session = getSession(interaction.user.id);
  if (!session) return interaction.update(expiredSessionReply());

  updateSession(interaction.user.id, { game: interaction.values[0] });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('order_materials_gotowe').setLabel('Mam gotowe klipy').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('order_materials_szukaj').setLabel('Znajdź momenty ze streama').setStyle(ButtonStyle.Primary)
  );

  await interaction.update({
    content: '**Krok 4/5 — Materiały:** czy masz gotowe klipy, czy mam wyszukać momenty ze streama?',
    components: [row],
  });
}

// ---------- KROK 4a: gotowe klipy -> modal ----------
async function handleMaterialsGotowe(interaction) {
  const session = getSession(interaction.user.id);
  if (!session) return interaction.update(expiredSessionReply());

  updateSession(interaction.user.id, { materialsType: 'gotowe', searchFeeTier: null });
  await showDetailsModal(interaction);
}

// ---------- KROK 4b: szukaj momentów -> wybór ilości materiału ----------
async function handleMaterialsSzukaj(interaction) {
  const session = getSession(interaction.user.id);
  if (!session) return interaction.update(expiredSessionReply());

  updateSession(interaction.user.id, { materialsType: 'szukaj' });

  const menu = new StringSelectMenuBuilder()
    .setCustomId('order_searchfee_select')
    .setPlaceholder('Ile materiału trzeba przejrzeć?')
    .addOptions(
      Object.values(prices.searchFee).map((s) => ({
        label: `${s.label} (+${s.price} zł)`,
        value: s.key,
      }))
    );

  await interaction.update({
    content: '**Krok 4/5 — Ile materiału ze streama trzeba przejrzeć?**',
    components: [new ActionRowBuilder().addComponents(menu)],
  });
}

async function handleSearchFeeSelect(interaction) {
  const session = getSession(interaction.user.id);
  if (!session) return interaction.update(expiredSessionReply());

  updateSession(interaction.user.id, { searchFeeTier: interaction.values[0] });
  await showDetailsModal(interaction);
}

// ---------- Modal: link do materiałów + uwagi ----------
async function showDetailsModal(interaction) {
  const modal = new ModalBuilder().setCustomId('order_details_modal').setTitle('Szczegóły zamówienia');

  const linkInput = new TextInputBuilder()
    .setCustomId('link')
    .setLabel('Link do materiałów (Google Drive / YouTube)')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(500);

  const notesInput = new TextInputBuilder()
    .setCustomId('notes')
    .setLabel('Uwagi do zamówienia (opcjonalnie)')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(1000);

  const discountInput = new TextInputBuilder()
    .setCustomId('discount_code')
    .setLabel('Kod rabatowy (opcjonalnie)')
    .setStyle(TextInputStyle.Short)
    .setRequired(false)
    .setMaxLength(50);

  modal.addComponents(
    new ActionRowBuilder().addComponents(linkInput),
    new ActionRowBuilder().addComponents(notesInput),
    new ActionRowBuilder().addComponents(discountInput)
  );

  await interaction.showModal(modal);
}

// ---------- Modal submit -> pytanie o timestampy ----------
async function handleDetailsModalSubmit(interaction) {
  const session = getSession(interaction.user.id);
  if (!session) {
    return interaction.reply({ ...expiredSessionReply(), ephemeral: true });
  }

  const link = interaction.fields.getTextInputValue('link').trim();
  const notes = interaction.fields.getTextInputValue('notes').trim();
  const discountCodeInput = interaction.fields.getTextInputValue('discount_code').trim();

  if (!URL_REGEX.test(link)) {
    return interaction.reply({
      content: '⚠️ Podany link wygląda nieprawidłowo — musi zaczynać się od `http://` lub `https://`. Spróbuj ponownie wpisując `/zamowienie` od kroku z linkiem (sesja nadal aktywna, kliknij przycisk materiałów ponownie).',
      ephemeral: true,
    });
  }

  let discountWarning = null;
  let discount = null;

  if (discountCodeInput) {
    const { validateDiscountCode } = require('../utils/discountCodes');
    const result = validateDiscountCode(discountCodeInput, session.guildId, interaction.user.id);
    if (result.valid) {
      discount = { code: discountCodeInput.trim().toUpperCase(), ...result.discount };
    } else {
      discountWarning = result.reason;
    }
  }

  updateSession(interaction.user.id, {
    materialsLink: link,
    notes: notes || null,
    discount,
    discountCodeInput: discountCodeInput || null,
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('order_timestamps_tak').setLabel('Tak, mam timestampy').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('order_timestamps_nie').setLabel('Nie mam timestampów').setStyle(ButtonStyle.Secondary)
  );

  const stepContent = discountWarning
    ? `⚠️ Kod rabatowy nieprawidłowy (${discountWarning}) — zamówienie idzie dalej bez rabatu.\n\n**Krok 5/5 — Czy masz przygotowane timestampy (momenty do wycięcia)?**`
    : '**Krok 5/5 — Czy masz przygotowane timestampy (momenty do wycięcia)?**';

  // Modal otwarty był z poziomu przycisku na oryginalnej wiadomości — można ją zaktualizować.
  await interaction.update({
    content: stepContent,
    components: [row],
  });
}

// ---------- Timestampy -> podsumowanie ----------
async function handleTimestamps(interaction, value) {
  const session = getSession(interaction.user.id);
  if (!session) return interaction.update(expiredSessionReply());

  updateSession(interaction.user.id, { hasTimestamps: value });
  const updated = getSession(interaction.user.id);

  const calc = calculateTotal(updated);

  let finalTotal = calc.total;
  let discountAmount = 0;
  if (updated.discount) {
    const { applyDiscount } = require('../utils/discountCodes');
    finalTotal = applyDiscount(calc.total, updated.discount);
    discountAmount = calc.total - finalTotal;
  }

  const embed = orderSummaryEmbed(updated, calc, { discountAmount, finalTotal, discountCode: updated.discount?.code });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('order_show_regulamin').setLabel('Pokaż regulamin').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('order_accept_terms').setLabel('✅ Akceptuję regulamin + start usługi').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('order_cancel_session').setLabel('Anuluj').setStyle(ButtonStyle.Danger)
  );

  await interaction.update({ content: '⚠️ Przed kliknięciem przycisku potwierdzasz akceptację regulaminu oraz wyraźnie żądasz rozpoczęcia realizacji usługi przed upływem 14 dni i przyjmujesz do wiadomości skutki tej decyzji opisane w regulaminie.', embeds: [embed], components: [row] });
}

// ---------- Anulowanie sesji ----------
async function handleCancelSession(interaction) {
  clearSession(interaction.user.id);
  await interaction.update({
    content: 'Zamówienie zostało anulowane przed złożeniem. Możesz zacząć od nowa poleceniem `/zamowienie`.',
    embeds: [],
    components: [],
  });
}

// ---------- Akceptacja regulaminu -> utworzenie zamówienia ----------
async function handleAcceptTerms(interaction) {
  const session = getSession(interaction.user.id);
  if (!session) return interaction.update(expiredSessionReply());

  const calc = calculateTotal(session);
  const db = getDb();
  const now = new Date().toISOString();

  // Re-walidacja kodu tuż przed zapisem — zabezpieczenie przed sytuacją, w której
  // kod wygasł/został zużyty w innej karcie/przeglądarce między krokiem modala a tym momentem.
  let finalTotal = calc.total;
  let discountAmount = 0;
  let appliedDiscountCode = null;

  if (session.discount) {
    const { validateDiscountCode, applyDiscount } = require('../utils/discountCodes');
    const revalidated = validateDiscountCode(session.discount.code, session.guildId, session.userId);
    if (revalidated.valid) {
      finalTotal = applyDiscount(calc.total, revalidated.discount);
      discountAmount = calc.total - finalTotal;
      appliedDiscountCode = session.discount.code;
    }
  }

  let orderId;
  try {
    db.transaction(() => {
      const result = db
        .prepare(
          `INSERT INTO orders
            (guild_id, user_id, package_key, package_name, is_bulk, base_price, addons, addons_price,
             game, materials_type, materials_link, search_fee, has_timestamps, notes, total_price,
             discount_code, discount_amount, status, created_at, updated_at)
           VALUES (@guild_id, @user_id, @package_key, @package_name, @is_bulk, @base_price, @addons, @addons_price,
             @game, @materials_type, @materials_link, @search_fee, @has_timestamps, @notes, @total_price,
             @discount_code, @discount_amount, 'pending_payment', @created_at, @updated_at)`
        )
        .run({
          guild_id: session.guildId, user_id: session.userId, package_key: session.packageKey, package_name: calc.packageName,
          is_bulk: session.isBulk ? 1 : 0, base_price: calc.base, addons: JSON.stringify(session.addons || []),
          addons_price: calc.addonsPrice, game: session.game, materials_type: session.materialsType,
          materials_link: session.materialsLink, search_fee: calc.searchFee, has_timestamps: session.hasTimestamps,
          notes: session.notes, total_price: finalTotal, discount_code: appliedDiscountCode, discount_amount: discountAmount,
          created_at: now, updated_at: now,
        });

      orderId = result.lastInsertRowid;
      if (appliedDiscountCode) {
        const { consumeDiscountCode } = require('../utils/discountCodes');
        if (!consumeDiscountCode(appliedDiscountCode, session.guildId, session.userId)) throw new Error('DISCOUNT_CONSUME_FAILED');
      }
      db.prepare('INSERT INTO terms_acceptance (user_id, order_id, accepted_at, terms_version, privacy_version, withdrawal_requested, withdrawal_acknowledged) VALUES (?, ?, ?, ?, ?, 1, 1)').run(
        session.userId, orderId, now, process.env.TERMS_VERSION || '2026-09-24', process.env.PRIVACY_VERSION || '2026-09-24'
      );
    })();
  } catch (err) {
    if (err.message === 'DISCOUNT_CONSUME_FAILED') {
      await interaction.editReply({ content: '⚠️ Ten kod rabatowy został właśnie wykorzystany lub wygasł. Spróbuj ponownie bez niego.', components: [] }).catch(() => {});
      return;
    }
    throw err;
  }

  clearSession(interaction.user.id);

  // Powiadomienie na kanale zamówień (jeśli skonfigurowany)
  const cfg = getConfig(session.guildId);
  if (cfg && (cfg.orders_channel_id || cfg.orders_notifications_channel_id)) {
    const targetId = cfg.orders_notifications_channel_id || cfg.orders_channel_id;
    const channel = await interaction.guild.channels.fetch(targetId).catch(() => null);
    if (channel) {
      const embed = new EmbedBuilder()
        .setColor(BRAND_COLOR)
        .setTitle(`🆕 Nowe zamówienie #${orderId}`)
        .setDescription(
          `<@${session.userId}> złożył(a) zamówienie: **${calc.packageName}** za **${finalTotal} zł**` +
            (appliedDiscountCode ? ` (rabat ${appliedDiscountCode}, -${discountAmount} zł)` : '') +
            '.'
        )
        .setTimestamp();
      await channel.send({ embeds: [embed] }).catch(() => {});
    }
  }

  await logEvent(
    interaction.client,
    session.guildId,
    'zamowienie',
    `Nowe zamówienie #${orderId} od <@${session.userId}> — ${calc.packageName}, ${finalTotal} zł${
      appliedDiscountCode ? ` (kod ${appliedDiscountCode})` : ''
    }.`
  );

  // Płatność online CashBill musi być inicjowana na stronie (montazyrant.pl),
  // nie bezpośrednio z bota — to wymóg operatora płatności co do domeny.
  // Tu tylko generujemy order_token i linkujemy do zamowienie.html; samą
  // płatność tworzy server/zamowienieRoutes.js, gdy klient kliknie tam
  // "Zamawiam i płacę teraz". W przeciwnym razie (CashBill/strona nieskonfigurowane)
  // zostaje ręczny BLIK/przelew jako awaryjna ścieżka.
  const { isCashbillConfigured } = require('../utils/cashbillClient');
  let zamowienieUrl = null;

  if (isCashbillConfigured() && process.env.SITE_URL) {
    try {
      const orderToken = crypto.randomBytes(24).toString('hex');
      db.prepare('UPDATE orders SET order_token = ? WHERE id = ?').run(orderToken, orderId);
      zamowienieUrl = `${process.env.SITE_URL}/zamowienie.html?order=${orderId}&token=${orderToken}`;
    } catch (err) {
      console.error('Błąd generowania linku do płatności:', err.message);
      await logEvent(
        interaction.client,
        session.guildId,
        'blad',
        `Nie udało się wygenerować linku płatności dla zamówienia #${orderId}: ${err.message}. Dostępna tylko płatność ręczna.`
      );
    }
  }

  const payEmbed = new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle('💳 Płatność')
    .setDescription(
      `Zamówienie **#${orderId}** zostało utworzone — łączna kwota: **${finalTotal} zł**` +
        (appliedDiscountCode ? ` (rabat ${appliedDiscountCode} już zastosowany, -${discountAmount} zł)` : '') +
        '.\n\n' +
        (zamowienieUrl
          ? '**Dokończ płatność online** przyciskiem poniżej — finalizacja odbywa się na stronie montazyrant.pl. Po potwierdzeniu płatności ticket utworzy się automatycznie.\n\n' +
            'Możesz też zapłacić ręcznie (BLIK na telefon / przelew) i kliknąć **„Zapłaciłem ręcznie"** — wtedy staff potwierdzi wpłatę osobiście.'
          : 'Dostępne metody płatności:\n• BLIK (na telefon)\n• Przelew bankowy\n\n' +
            'Po dokonaniu płatności kliknij przycisk **„Zapłaciłem"** poniżej — utworzę ticket, w którym ustalimy szczegóły.')
    );

  const row = new ActionRowBuilder();
  if (zamowienieUrl) {
    row.addComponents(
      new ButtonBuilder()
        .setLabel('💳 Dokończ płatność online')
        .setStyle(ButtonStyle.Link)
        .setURL(zamowienieUrl)
    );
  }
  row.addComponents(
    new ButtonBuilder()
      .setCustomId(`pay_confirm_${orderId}`)
      .setLabel(zamowienieUrl ? 'Zapłaciłem ręcznie' : 'Zapłaciłem')
      .setStyle(ButtonStyle.Success)
      .setEmoji('💸')
  );

  await interaction.update({ content: '', embeds: [payEmbed], components: [row] });
}

async function handleShowRegulamin(interaction) {
  const { regulaminEmbed } = require('../utils/embeds');
  await interaction.reply({ embeds: [regulaminEmbed()], ephemeral: true });
}

module.exports = {
  handlePackageSelect,
  handleAddonsSelect,
  handleGameSelect,
  handleMaterialsGotowe,
  handleMaterialsSzukaj,
  handleSearchFeeSelect,
  handleDetailsModalSubmit,
  handleTimestamps,
  handleCancelSession,
  handleAcceptTerms,
  handleShowRegulamin,
};
