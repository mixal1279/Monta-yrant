// handlers/pricingButtons.js
// Obsługuje przyciski dołączone do wiadomości z cennikiem: Zamów / Regulamin / Opinie / Portfolio.

const { regulaminEmbed } = require('../utils/embeds');
const { getConfig } = require('../config/config');
const { overallStats } = require('../utils/exportData');
const { startOrderFlow } = require('../commands/zamowienie');

async function handlePricingButton(interaction, action) {
  if (action === 'zamow') {
    return startOrderFlow(interaction);
  }

  if (action === 'regulamin') {
    return interaction.reply({ embeds: [regulaminEmbed()], ephemeral: true });
  }

  if (action === 'opinie') {
    const cfg = getConfig(interaction.guildId);
    const stats = overallStats(interaction.guildId);
    const text =
      stats.reviewCount > 0
        ? `⭐ Średnia ocena: **${stats.avgRating}/5** (${stats.reviewCount} opinii).${
            cfg?.reviews_channel_id ? `\nWszystkie opinie znajdziesz na <#${cfg.reviews_channel_id}>.` : ''
          }`
        : 'Nie ma jeszcze żadnych opinii.';
    return interaction.reply({ content: text, ephemeral: true });
  }

  if (action === 'portfolio') {
    const cfg = getConfig(interaction.guildId);
    return interaction.reply({
      content: cfg?.portfolio_channel_id
        ? `Przykładowe realizacje znajdziesz na <#${cfg.portfolio_channel_id}>.`
        : 'Kanał portfolio nie jest jeszcze skonfigurowany.',
      ephemeral: true,
    });
  }
}

module.exports = { handlePricingButton };
