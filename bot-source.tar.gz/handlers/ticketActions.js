// handlers/ticketActions.js
// Obsługuje: przycisk "Zapłaciłem" (tworzy ticket) oraz przyciski zmiany
// statusu zamówienia wewnątrz ticketu (Opłacone / W trakcie / Dostarczone / Anuluj...).

const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, StringSelectMenuBuilder } = require('discord.js');
const { getDb } = require('../database/db');
const { createTicketForOrder, closeTicketButtonRow } = require('../tickets/ticketManager');
const { logEvent } = require('../utils/logger');
const { statusLabel, BRAND_COLOR } = require('../utils/embeds');
const { getConfig } = require('../config/config');
const { isStaffMember } = require('../utils/permissions');

function getOrder(orderId) {
  return getDb().prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
}

function setStatus(orderId, status) {
  getDb()
    .prepare('UPDATE orders SET status = ?, updated_at = ? WHERE id = ?')
    .run(status, new Date().toISOString(), orderId);
}

// ---------- Przycisk "Zapłaciłem" ----------
async function handlePayConfirm(interaction, orderId) {
  const order = getOrder(orderId);
  if (!order) {
    return interaction.reply({ content: 'Nie znaleziono tego zamówienia.', ephemeral: true });
  }
  if (order.user_id !== interaction.user.id) {
    return interaction.reply({ content: 'To nie jest Twoje zamówienie.', ephemeral: true });
  }
  if (order.ticket_channel_id) {
    return interaction.reply({
      content: `Ticket dla tego zamówienia już istnieje: <#${order.ticket_channel_id}>`,
      ephemeral: true,
    });
  }

  await interaction.deferUpdate();

  getDb().prepare('UPDATE orders SET payment_method = ? WHERE id = ?').run('reczne', orderId);

  try {
    const channel = await createTicketForOrder(interaction.client, interaction.guild, order);
    await interaction.editReply({
      content: `✅ Dziękuję! Utworzyłem ticket: <#${channel.id}> — tam ustalimy szczegóły płatności.`,
      embeds: [],
      components: [],
    });
  } catch (err) {
    console.error(err);
    await interaction.editReply({
      content: `⚠️ Nie udało się utworzyć ticketu: ${err.message}`,
      embeds: [],
      components: [],
    });
  }
}

// ---------- Przyciski statusu w tickecie (tylko staff/admin) ----------
async function handleStatusButton(interaction, status, orderId) {
  const cfg = getConfig(interaction.guildId);
  const member = interaction.member;
  const isStaff = isStaffMember(member, cfg);

  if (!isStaff) {
    return interaction.reply({ content: 'Tylko staff może zmieniać status zamówienia.', ephemeral: true });
  }

  const order = getOrder(orderId);
  if (!order) {
    return interaction.reply({ content: 'Nie znaleziono zamówienia.', ephemeral: true });
  }

  setStatus(orderId, status);

  if (status === 'paid') {
    const { maybeSetPriorityDeadline } = require('../utils/priorityTracking');
    maybeSetPriorityDeadline(orderId);
  }

  if (status === 'delivered') {
    getDb()
      .prepare('UPDATE orders SET delivered_at = ? WHERE id = ?')
      .run(new Date().toISOString(), orderId);
  }

  await interaction.reply({
    content: `Status zamówienia #${orderId} zmieniony na: **${statusLabel(status)}**`,
  });

  await logEvent(
    interaction.client,
    interaction.guildId,
    status === 'cancelled' ? 'anulowanie' : status === 'delivered' ? 'ukonczenie' : 'platnosc',
    `Zamówienie #${orderId} — status: ${statusLabel(status)} (zmienił: <@${interaction.user.id}>).`
  );

  if (status === 'delivered') {
    await askPortfolioConsent(interaction.channel, order);
  }
}

// ---------- Po dostarczeniu: pytanie o zgodę na portfolio ----------
async function askPortfolioConsent(channel, order) {
  const embed = new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setDescription(`<@${order.user_id}> — czy zgadzasz się na publikację tego materiału w portfolio?`);

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`portfolio_consent_tak_${order.id}`).setLabel('Tak').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`portfolio_consent_nie_${order.id}`).setLabel('Nie').setStyle(ButtonStyle.Secondary)
  );

  await channel.send({ embeds: [embed], components: [row] });
}

async function handlePortfolioConsent(interaction, consent, orderId) {
  const order = getOrder(orderId);
  if (!order) return interaction.reply({ content: 'Nie znaleziono zamówienia.', ephemeral: true });
  if (order.user_id !== interaction.user.id) {
    return interaction.reply({ content: 'Tylko klient zamówienia może odpowiedzieć.', ephemeral: true });
  }

  const consented = consent === 'tak';
  getDb().prepare('UPDATE orders SET portfolio_consent = ? WHERE id = ?').run(consented ? 1 : 0, orderId);

  if (consented) {
    const cfg = getConfig(interaction.guildId);
    if (cfg && cfg.portfolio_channel_id) {
      const portfolioChannel = await interaction.guild.channels.fetch(cfg.portfolio_channel_id).catch(() => null);
      if (portfolioChannel) {
        const embed = new EmbedBuilder()
          .setColor(BRAND_COLOR)
          .setTitle(`🎬 Portfolio — ${order.package_name}`)
          .addFields(
            { name: 'Gra', value: order.game || '—', inline: true },
            { name: 'Pakiet', value: order.package_name, inline: true },
            { name: 'Data', value: new Date().toLocaleDateString('pl-PL'), inline: true },
            { name: 'Materiał', value: order.materials_link || '—', inline: false }
          );
        await portfolioChannel.send({ embeds: [embed] }).catch(() => {});
      }
    }
  }

  // Po decyzji o portfolio — prośba o ocenę
  const ratingRow = new ActionRowBuilder().addComponents(
    [1, 2, 3, 4, 5].map((n) =>
      new ButtonBuilder().setCustomId(`review_rating_${n}_${order.id}`).setLabel('⭐'.repeat(n)).setStyle(ButtonStyle.Secondary)
    )
  );

  await interaction.reply({
    content: consented
      ? '✅ Dziękuję! Materiał trafi do portfolio.\n\nNa koniec — oceń realizację:'
      : 'Rozumiem, materiał nie zostanie opublikowany w portfolio.\n\nNa koniec — oceń realizację:',
    components: [ratingRow],
  });
}

// ---------- Przycisk "Zamknij ticket" ----------
async function handleCloseTicket(interaction, orderId) {
  const cfg = getConfig(interaction.guildId);
  const member = interaction.member;
  const isStaff = isStaffMember(member, cfg);

  if (!isStaff) {
    return interaction.reply({ content: 'Tylko staff może zamknąć ticket.', ephemeral: true });
  }

  const order = getOrder(orderId);
  if (!order) {
    return interaction.reply({ content: 'Nie znaleziono zamówienia.', ephemeral: true });
  }

  await interaction.reply({ content: '🔒 Zamykam ticket za 5 sekund...' });

  await logEvent(
    interaction.client,
    interaction.guildId,
    'zamowienie',
    `Ticket zamówienia #${orderId} zamknięty przez <@${interaction.user.id}>.`
  );

  setTimeout(async () => {
    try {
      await interaction.channel.delete();
    } catch (err) {
      console.error('Błąd przy usuwaniu kanału ticketu:', err.message);
    }
  }, 5000);
}

module.exports = { handlePayConfirm, handleStatusButton, handlePortfolioConsent, handleCloseTicket };
