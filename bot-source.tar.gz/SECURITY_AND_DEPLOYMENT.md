# MontaŻyrant — bezpieczeństwo wdrożenia

## Przed produkcją
- Nie umieszczaj `database/*.db`, `database/*.db-*`, `backups/` ani eksportów w repozytorium.
- Ustaw `SITE_URL`, `DISCORD_OAUTH_PUBLIC_URL` i `SITE_COOKIE_DOMAIN` wyłącznie na własne domeny HTTPS.
- Ustaw `CASHBILL_*` zgodnie z aktualną dokumentacją CashBill. Aplikacja działa fail-closed, jeśli brakuje endpointu tworzenia lub odczytu statusu.
- Nie publikuj `.env` ani sekretów Discord/CashBill.
- Uzupełnij prawdziwe dane identyfikacyjne i adres Usługodawcy w `regulamin.html` i `privacy.html`.
- Przed sprzedażą konsumencką zweryfikuj dokumenty z prawnikiem/UOKiK-ready checklistą.

## Płatności
Aplikacja nie uznaje płatności na podstawie samego URL powrotnego. Callback CashBill jest weryfikowany podpisem, a status i kwota są dodatkowo pobierane z API.

## Backupy
Backup wykonuje checkpoint WAL przed kopiowaniem. Backupów nie należy przechowywać w katalogu dostępnym przez WWW ani w repozytorium. Zalecane jest szyfrowanie i ograniczenie uprawnień systemowych.

## Rate limiting
Limiter jest lokalny dla procesu Node. Przy wielu instancjach zastąp go rozwiązaniem współdzielonym.
