// server/zamowienieRoutes.js
// Finalizacja zamówienia na stronie (montazyrant.pl) — wymóg CashBill, żeby
// potwierdzenie zamówienia i inicjacja płatności odbywały się w obrębie
// zgłoszonej domeny, niezależnie od tego, czy klient zaczął na stronie czy
// na Discordzie (patrz handlers/orderFlow.js — tam generujemy order_token
// i tylko linkujemy tutaj, zamiast tworzyć płatność bezpośrednio z bota).
//
// Od tej wersji proces na stronie odzwierciedla PEŁNY flow z /zamowienie na
// Discordzie (handlers/orderFlow.js): pakiety pojedyncze i zbiorcze, dodatki,
// gra, materiały (gotowe / szukanie momentów + opłata za przegląd), link,
// uwagi, kod rabatowy, timestampy — nie tylko sam wybór pakietu jak wcześniej.
// Logika liczenia sumy i walidacji kodu celowo powiela tę z utils/pricing.js
// i utils/discountCodes.js (te moduły są pisane pod sesję w pamięci bota,
// nie nadają się do importu 1:1 dla żądania HTTP), ale korzysta z tych samych
// źródeł danych (prices.json, tabela discount_codes) i tych samych funkcji
// walidacyjnych/rabatowych — nie duplikuje samej logiki rabatu.
//
// Nie duplikujemy integracji CashBill — używamy tych samych funkcji z
// utils/cashbillClient.js i tej samej funkcji potwierdzającej płatność
// (confirmCashbillPaid) co server/cashbillServer.js i commands/platnosc.js.

const crypto = require('crypto');
const { EmbedBuilder } = require('discord.js');
const { getDb } = require('../database/db');
const { prices, getPackage, getBulkPackage, getAddon, getSearchFeeTier } = require('../utils/pricing');
const { validateDiscountCode, applyDiscount, consumeDiscountCode } = require('../utils/discountCodes');
const { getSession } = require('../utils/discordSessionStore');
const { parseCookies } = require('../utils/cookies');
const { SESSION_COOKIE } = require('./discordAuthRoutes');
const { isCashbillConfigured, createCashbillPayment, getCashbillPayment } = require('../utils/cashbillClient');
const { confirmCashbillPaid } = require('./cashbillServer');
const { logEvent } = require('../utils/logger');
const { getConfig } = require('../config/config');
const { BRAND_COLOR } = require('../utils/embeds');
const { rateLimit } = require('../utils/rateLimit');

const GUILD_ID = process.env.GUILD_ID;
const URL_REGEX = /^https?:\/\/.+/i;
const MAX_NOTES_LENGTH = 1000;

// Pełna lista statusów CashBill wg commands/platnosc.js. "PositiveFinish" =
// już opłacone (nie twórz nowej płatności, tylko potwierdź). Statusy poniżej
// są terminalne/nieudane — dla nich bezpiecznie utworzyć nową płatność.
// Wszystko inne (np. "Start", "PositiveAuthorization" — płatność wciąż w toku)
// traktujemy jako aktywne i oddajemy istniejący checkoutUrl ponownie, żeby
// nie zdublować transakcji.
const CASHBILL_PAID_STATUS = 'PositiveFinish';
const paymentLocks = new Set();
const CASHBILL_FAILED_STATUSES = new Set([
  'NegativeAuthorization',
  'Abort',
  'Fraud',
  'NegativeFinish',
  'TimeExceeded',
  'CriticalError',
]);

function getSessionFromRequest(req) {
  const cookies = parseCookies(req);
  return getSession(cookies[SESSION_COOKIE]);
}

function generateOrderToken() {
  return crypto.randomBytes(24).toString('hex');
}

function findOrderByToken(db, orderId, token) {
  if (!Number.isSafeInteger(Number(orderId)) || Number(orderId) <= 0 || typeof token !== 'string' || !/^[a-f0-9]{48}$/.test(token)) return null;
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  if (!order || !order.order_token || order.order_token !== token) return null;
  return order;
}

// Rozwiązuje klucz pakietu na dane pakietu, sprawdzając zarówno pojedyncze,
// jak i zbiorcze — dokładnie jak getAllPackageOptions() w bocie. isBulk jest
// zawsze wyliczane po stronie serwera, nigdy nie ufamy temu, co przyśle klient.
function resolvePackage(packageKey) {
  const single = getPackage(packageKey);
  if (single) return { isBulk: false, base: single.price, name: single.name };
  const bulk = getBulkPackage(packageKey);
  if (bulk) return { isBulk: true, base: bulk.price, name: bulk.name };
  return null;
}

// Waliduje i liczy całe zamówienie z surowego payloadu żądania. Zwraca albo
// { error } (kod błędu + wiadomość do pokazania), albo gotowy obiekt do zapisu.
function buildOrderFromPayload(body, session) {
  const packageKey = body.packageKey;
  const resolved = packageKey ? resolvePackage(packageKey) : null;
  if (!resolved) return { error: { status: 400, code: 'invalid_package', message: 'Nieprawidłowy pakiet.' } };

  const addonsInput = Array.isArray(body.addons) ? body.addons : [];
  const addonKeys = [];
  let addonsPrice = 0;
  for (const key of addonsInput) {
    const addon = getAddon(key);
    if (!addon) return { error: { status: 400, code: 'invalid_addon', message: `Nieznany dodatek: ${key}.` } };
    addonKeys.push(addon.key);
    addonsPrice += addon.price;
  }

  const game = typeof body.game === 'string' ? body.game.trim() : '';
  if (!prices.games.includes(game)) {
    return { error: { status: 400, code: 'invalid_game', message: 'Wybierz grę z listy.' } };
  }

  const materialsType = body.materialsType;
  if (materialsType !== 'gotowe' && materialsType !== 'szukaj') {
    return { error: { status: 400, code: 'invalid_materials_type', message: 'Nieprawidłowy typ materiałów.' } };
  }

  let searchFee = 0;
  if (materialsType === 'szukaj') {
    const tier = getSearchFeeTier(body.searchFeeTier);
    if (!tier) return { error: { status: 400, code: 'invalid_search_fee', message: 'Wybierz, ile materiału trzeba przejrzeć.' } };
    searchFee = tier.price;
  }

  const materialsLink = typeof body.materialsLink === 'string' ? body.materialsLink.trim() : '';
  if (!URL_REGEX.test(materialsLink)) {
    return { error: { status: 400, code: 'invalid_link', message: 'Link do materiałów musi zaczynać się od http:// lub https://.' } };
  }

  const notesRaw = typeof body.notes === 'string' ? body.notes.trim() : '';
  const notes = notesRaw.slice(0, MAX_NOTES_LENGTH) || null;

  const hasTimestamps = body.hasTimestamps === 'tak' ? 'tak' : 'nie';

  if (body.termsAccepted !== true) {
    return { error: { status: 400, code: 'terms_not_accepted', message: 'Musisz zaakceptować regulamin, żeby złożyć zamówienie.' } };
  }

  const subtotal = resolved.base + addonsPrice + searchFee;

  let finalTotal = subtotal;
  let discountAmount = 0;
  let appliedDiscountCode = null;
  let discountWarning = null;

  const discountInput = typeof body.discountCode === 'string' ? body.discountCode.trim() : '';
  if (discountInput) {
    const result = validateDiscountCode(discountInput, GUILD_ID, session.discordId);
    if (result.valid) {
      finalTotal = applyDiscount(subtotal, result.discount);
      discountAmount = subtotal - finalTotal;
      appliedDiscountCode = discountInput.toUpperCase();
    } else {
      discountWarning = result.reason;
    }
  }

  return {
    order: {
      isBulk: resolved.isBulk,
      packageKey,
      packageName: resolved.name,
      basePrice: resolved.base,
      addons: addonKeys,
      addonsPrice,
      game,
      materialsType,
      materialsLink,
      searchFee,
      notes,
      hasTimestamps,
      subtotal,
      finalTotal,
      discountAmount,
      appliedDiscountCode,
      discountWarning,
    },
  };
}

function orderSummary(order) {
  const addons = JSON.parse(order.addons || '[]').map((key) => {
    const addon = getAddon(key);
    return { key, name: addon ? addon.name : key, price: addon ? addon.price : 0 };
  });

  return {
    orderId: order.id,
    status: order.status,
    packageKey: order.package_key,
    packageName: order.package_name,
    isBulk: Boolean(order.is_bulk),
    basePrice: order.base_price,
    addons,
    addonsPrice: order.addons_price,
    game: order.game,
    materialsType: order.materials_type,
    materialsLink: order.materials_link,
    searchFee: order.search_fee,
    hasTimestamps: order.has_timestamps,
    notes: order.notes,
    discountCode: order.discount_code,
    discountAmount: order.discount_amount,
    price: order.total_price,
  };
}

async function notifyOrdersChannel(client, orderId, orderData, session) {
  const cfg = getConfig(GUILD_ID);
  if (!cfg || (!cfg.orders_channel_id && !cfg.orders_notifications_channel_id)) return;
  const targetId = cfg.orders_notifications_channel_id || cfg.orders_channel_id;
  const channel = await client.channels.fetch(targetId).catch(() => null);
  if (!channel) return;

  const embed = new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle(`🆕 Nowe zamówienie #${orderId} (strona)`)
    .setDescription(
      `<@${session.discordId}> złożył(a) zamówienie przez stronę: **${orderData.packageName}** za **${orderData.finalTotal} zł**` +
        (orderData.appliedDiscountCode ? ` (rabat ${orderData.appliedDiscountCode}, -${orderData.discountAmount} zł)` : '') +
        '.'
    )
    .setTimestamp();

  await channel.send({ embeds: [embed] }).catch(() => {});
}

function registerZamowienieRoutes(app, client) {
  // Tworzy zamówienie zainicjowane ze strony. Wymaga zalogowania przez
  // Discord (ten sam mechanizm co quiz — cookie sesji). Odpowiada temu, co
  // handlers/orderFlow.js robi na Discordzie po kroku "Akceptuję regulamin".
  app.post('/api/zamowienie', rateLimit({ windowMs: 10 * 60_000, max: 5, keyGenerator: (req) => { const s = getSessionFromRequest(req); return s?.discordId || req.ip || 'unknown'; } }), async (req, res) => {
    if (!GUILD_ID) return res.status(500).json({ error: 'missing_guild_id' });
    const session = getSessionFromRequest(req);
    if (!session) return res.status(401).json({ error: 'not_logged_in' });

    const result = buildOrderFromPayload(req.body || {}, session);
    if (result.error) return res.status(result.error.status).json({ error: result.error.code, message: result.error.message });

    const orderData = result.order;
    const db = getDb();
    const now = new Date().toISOString();
    const orderToken = generateOrderToken();
    const termsVersion = String(process.env.TERMS_VERSION || '2026-09-24');
    const privacyVersion = String(process.env.PRIVACY_VERSION || '2026-09-24');
    const withdrawalRequested = req.body.withdrawalRequested === true;
    const withdrawalAcknowledged = req.body.withdrawalAcknowledged === true;
    if (!withdrawalRequested || !withdrawalAcknowledged) {
      return res.status(400).json({ error: 'withdrawal_consent_required', message: 'Przed rozpoczęciem realizacji musisz wyraźnie zażądać rozpoczęcia usługi przed upływem terminu odstąpienia i potwierdzić informację o skutkach tej decyzji.' });
    }

    let orderId;
    try {
      db.transaction(() => {
        const insertResult = db.prepare(`INSERT INTO orders
          (guild_id, user_id, package_key, package_name, is_bulk, base_price, addons, addons_price,
           game, materials_type, materials_link, search_fee, has_timestamps, notes, total_price,
           discount_code, discount_amount, status, order_token, created_at, updated_at)
         VALUES (@guild_id, @user_id, @package_key, @package_name, @is_bulk, @base_price, @addons, @addons_price,
           @game, @materials_type, @materials_link, @search_fee, @has_timestamps, @notes, @total_price,
           @discount_code, @discount_amount, 'pending_payment', @order_token, @created_at, @updated_at)`).run({
          guild_id: GUILD_ID, user_id: session.discordId, package_key: orderData.packageKey,
          package_name: orderData.packageName, is_bulk: orderData.isBulk ? 1 : 0, base_price: orderData.basePrice,
          addons: JSON.stringify(orderData.addons), addons_price: orderData.addonsPrice, game: orderData.game,
          materials_type: orderData.materialsType, materials_link: orderData.materialsLink, search_fee: orderData.searchFee,
          has_timestamps: orderData.hasTimestamps, notes: orderData.notes, total_price: orderData.finalTotal,
          discount_code: orderData.appliedDiscountCode, discount_amount: orderData.discountAmount,
          order_token: orderToken, created_at: now, updated_at: now,
        });
        orderId = insertResult.lastInsertRowid;

        db.prepare(`INSERT INTO terms_acceptance
          (user_id, order_id, accepted_at, terms_version, privacy_version, withdrawal_requested, withdrawal_acknowledged, accepted_ip)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(
          session.discordId, orderId, now, termsVersion, privacyVersion, 1, 1, req.ip || null
        );

        if (orderData.appliedDiscountCode && !consumeDiscountCode(orderData.appliedDiscountCode, GUILD_ID, session.discordId)) {
          throw new Error('DISCOUNT_CONSUME_FAILED');
        }
      })();
    } catch (err) {
      if (err.message === 'DISCOUNT_CONSUME_FAILED') {
        return res.status(409).json({ error: 'discount_unavailable', message: 'Kod rabatowy został właśnie wykorzystany albo wygasł. Odśwież podsumowanie i spróbuj ponownie.' });
      }
      console.error('Błąd tworzenia zamówienia:', err);
      return res.status(500).json({ error: 'order_create_failed', message: 'Nie udało się utworzyć zamówienia.' });
    }

    logEvent(client, GUILD_ID, 'zamowienie', `Nowe zamówienie #${orderId} złożone przez stronę (<@${session.discordId}>) — ${orderData.packageName}, ${orderData.finalTotal} zł` + (orderData.appliedDiscountCode ? ` (kod ${orderData.appliedDiscountCode})` : '') + '.').catch(() => {});
    notifyOrdersChannel(client, orderId, orderData, session).catch(() => {});

    res.setHeader('Cache-Control', 'no-store');
    res.json({ orderId, token: orderToken, discountApplied: Boolean(orderData.appliedDiscountCode), discountWarning: orderData.discountWarning });
  });

  // Podsumowanie zamówienia — dostęp wyłącznie przez zgadujący się token w URL,
  // bez wymogu sesji (żeby działało też z linku wklejonego z Discorda).
  app.get('/api/zamowienie/:id', (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const orderId = Number(req.params.id);
    const token = req.query.token;
    const db = getDb();
    const order = findOrderByToken(db, orderId, token);
    if (!order) return res.status(404).json({ error: 'not_found' });
    res.json(orderSummary(order));
  });

  // Inicjuje (lub bezpiecznie ponawia) płatność CashBill dla zamówienia.
  app.post('/api/zamowienie/:id/platnosc', rateLimit({ windowMs: 5 * 60_000, max: 6, keyGenerator: (req) => req.ip || 'unknown' }), async (req, res) => {
    const orderId = Number(req.params.id);
    const token = req.query.token;
    const db = getDb();
    const order = findOrderByToken(db, orderId, token);
    if (!order) return res.status(404).json({ error: 'not_found' });
    res.setHeader('Cache-Control', 'no-store');

    if (order.status !== 'pending_payment') {
      return res.status(409).json({ error: 'not_payable', status: order.status });
    }
    if (!isCashbillConfigured()) {
      return res.status(503).json({
        error: 'cashbill_not_configured',
        message: 'Płatność online jest chwilowo niedostępna. Napisz do nas na Discordzie.',
      });
    }
    if (paymentLocks.has(orderId)) return res.status(409).json({ error: 'payment_already_initializing', message: 'Płatność jest właśnie inicjalizowana. Spróbuj ponownie za chwilę.' });
    paymentLocks.add(orderId);

    try {
      if (order.cashbill_payment_id) {
        let payment;
        try {
          payment = await getCashbillPayment(order.cashbill_payment_id);
        } catch (lookupError) {
          console.error('Nie udało się zweryfikować istniejącej płatności CashBill:', lookupError.message);
          return res.status(502).json({ error: 'cashbill_status_unavailable', message: 'Nie można bezpiecznie zweryfikować istniejącej płatności. Spróbuj ponownie później.' });
        }

        if (payment && payment.status === CASHBILL_PAID_STATUS) {
          // Płatność już zaksięgowana (np. webhook przetworzył się w międzyczasie) —
          // dobijamy stan zamówienia (idempotentne, patrz cashbillServer.js) zamiast
          // tworzyć drugą płatność.
          await confirmCashbillPaid(client, orderId, payment).catch(() => {});
          return res.status(409).json({ error: 'already_paid', message: 'To zamówienie zostało już opłacone.' });
        }

        if (payment && !CASHBILL_FAILED_STATUSES.has(payment.status) && order.cashbill_checkout_url) {
          return res.json({ checkoutUrl: order.cashbill_checkout_url });
        }
        // Brak odpowiedzi z CashBill albo status nieudany/wygasły — twórz nową płatność poniżej.
      }

      const cashbillPayment = await createCashbillPayment(order);
      const saved = db.prepare(`UPDATE orders SET cashbill_payment_id = ?, cashbill_transaction_id = ?, cashbill_checkout_url = ?, updated_at = ? WHERE id = ? AND status = 'pending_payment' AND (cashbill_payment_id IS NULL OR cashbill_payment_id = '')`).run(cashbillPayment.paymentId, cashbillPayment.paymentId, cashbillPayment.checkoutUrl, new Date().toISOString(), orderId);
      if (!saved.changes) {
        const current = db.prepare('SELECT cashbill_checkout_url FROM orders WHERE id = ?').get(orderId);
        if (current?.cashbill_checkout_url) return res.json({ checkoutUrl: current.cashbill_checkout_url });
        return res.status(409).json({ error: 'payment_already_initializing' });
      }

      res.json({ checkoutUrl: cashbillPayment.checkoutUrl });
    } catch (err) {
      console.error('Błąd tworzenia płatności CashBill (strona):', err.message);
      await logEvent(
        client,
        order.guild_id,
        'blad',
        `Nie udało się utworzyć płatności CashBill (strona) dla zamówienia #${orderId}: ${err.message}.`
      ).catch(() => {});
      res.status(502).json({ error: 'cashbill_error', message: 'Nie udało się utworzyć płatności. Spróbuj ponownie za chwilę.' });
    } finally {
      paymentLocks.delete(orderId);
    }
  });
}

module.exports = { registerZamowienieRoutes };
