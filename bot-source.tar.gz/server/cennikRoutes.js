// server/cennikRoutes.js
// Publiczny cennik. Dane bez sekretów — bot i strona mają czytać z jednego
// źródła (prices.json), żeby cena nigdy nie rozjechała się między nimi.
const { prices } = require('../utils/pricing');

function registerCennikRoutes(app) {
  app.get('/api/cennik', (req, res) => {
    res.set('Cache-Control', 'public, max-age=60');
    res.json(prices);
  });
}

module.exports = { registerCennikRoutes };
