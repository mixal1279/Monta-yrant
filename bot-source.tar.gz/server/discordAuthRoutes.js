// server/discordAuthRoutes.js
// Logowanie przez Discord przed kręceniem kołem fortuny na stronie. W
// odróżnieniu od googleAuthRoutes.js (gdzie userId jest znany z góry, bo
// komenda /sprawdz-rabat startuje flow na Discordzie) — tutaj NIE znamy
// Discord ID zanim klient się nie zaloguje, więc state niesie tylko ochronę
// CSRF (userId/guildId w oauthStateStore zostają puste/GUILD_ID).
//
// Po udanym logowaniu ustawiamy httpOnly cookie sesji (utils/discordSessionStore)
// i odsyłamy klienta z powrotem na stronę — spinRoutes.js czyta tę sesję,
// żeby wiedzieć KTO kręci, zamiast opierać się wyłącznie na adresie IP.

const { createState, consumeState } = require('../utils/oauthStateStore');
const { isDiscordOAuthConfigured, buildAuthUrl, exchangeCodeForUser } = require('../utils/discordAuth');
const { createSession, getSession } = require('../utils/discordSessionStore');
const { setCookie, parseCookies } = require('../utils/cookies');

const GUILD_ID = process.env.GUILD_ID;
const SESSION_COOKIE = 'mz_discord_session';
const OAUTH_STATE_COOKIE = 'mz_oauth_state';
const SESSION_TTL_MS = 30 * 60 * 1000;
const { rateLimit } = require('../utils/rateLimit');

function page(title, message, ok) {
  return `<html><body style="font-family:sans-serif;text-align:center;padding:60px">
    <h1>${ok ? '✅' : '❌'} ${title}</h1>
    <p>${message}</p>
  </body></html>`;
}

// Akceptujemy tylko ścieżkę względną na tej samej domenie (zaczyna się od
// pojedynczego "/", nie "//") — inaczej ktoś mógłby podesłać link logowania
// z ?next=https://zlosliwa-strona.pl i przekierować ofiarę po zalogowaniu.
function sanitizeNext(next) {
  if (typeof next !== 'string' || !next) return null;
  if (!/^\/(?!\/)/.test(next)) return null;
  return next;
}

function buildReturnUrl(siteUrl, next) {
  if (!next) return `${siteUrl}?discord_login=success`;
  const sep = next.includes('?') ? '&' : '?';
  return `${siteUrl}${next}${sep}discord_login=success`;
}

function registerDiscordAuthRoutes(app) {
  app.get('/oauth/discord/login', rateLimit({ windowMs: 10 * 60_000, max: 10 }), (req, res) => {
    if (!isDiscordOAuthConfigured()) {
      return res.status(500).send(page('Błąd konfiguracji', 'Logowanie przez Discord nie jest jeszcze skonfigurowane.', false));
    }
    // userId nieznany na tym etapie — state służy tu wyłącznie jako CSRF nonce
    // (+ opcjonalnie niesie ścieżkę powrotu, np. do zamowienie.html?pakiet=X).
    const next = sanitizeNext(req.query.next);
    const state = createState(null, GUILD_ID, next);
    // Host-only cookie wiąże OAuth state z przeglądarką, która rozpoczęła flow.
    // Nie używamy tu SITE_COOKIE_DOMAIN, żeby siostrzana subdomena nie mogła
    // nadpisać nonce OAuth.
    setCookie(res, OAUTH_STATE_COOKIE, state, 10 * 60 * 1000, { domain: false });
    res.redirect(buildAuthUrl(state));
  });

  app.get('/oauth/discord/callback', rateLimit({ windowMs: 10 * 60_000, max: 20 }), async (req, res) => {
    const { code, state, error } = req.query;
    if (typeof code !== 'string' || !code || typeof state !== 'string' || !state) {
      return res.status(400).send(page('Nieprawidłowy callback', 'Brakuje wymaganych parametrów logowania.', false));
    }

    if (error) {
      return res.send(page('Anulowano', 'Nie udzielono zgody na logowanie. Wróć na stronę i spróbuj ponownie.', false));
    }

    const cookies = parseCookies(req);
    const stateCookie = cookies[OAUTH_STATE_COOKIE];
    if (!state || !stateCookie || stateCookie !== state) {
      clearCookie(res, OAUTH_STATE_COOKIE, { domain: false });
      return res.status(400).send(page('Nieprawidłowy login', 'Sesja logowania nie została rozpoczęta w tej przeglądarce. Wróć na stronę i spróbuj ponownie.', false));
    }
    clearCookie(res, OAUTH_STATE_COOKIE, { domain: false });

    const stateData = consumeState(state);
    if (!stateData) {
      return res.status(400).send(page('Link wygasł', 'Ten link wygasł albo już został użyty. Wróć na stronę i kliknij "Zaloguj przez Discord" ponownie.', false));
    }

    let discordUser;
    try {
      discordUser = await exchangeCodeForUser(code);
    } catch (err) {
      console.error('Błąd logowania Discord OAuth:', err.message);
      return res.status(500).send(page('Błąd', 'Coś poszło nie tak przy logowaniu. Spróbuj ponownie.', false));
    }

    const token = createSession(discordUser);
    setCookie(res, SESSION_COOKIE, token, SESSION_TTL_MS);

    const returnUrl = process.env.SITE_URL;
    if (returnUrl) {
      return res.redirect(buildReturnUrl(returnUrl, stateData.extra));
    }
    res.send(page('Zalogowano!', `Zalogowano jako ${discordUser.username}. Możesz wrócić na kartę ze stroną i kontynuować.`, true));
  });

  // Front pyta o to przy wejściu na stronę, żeby wiedzieć czy pokazać przycisk
  // "Zaloguj przez Discord" czy od razu "Zakręć kołem" — bez tego trzeba by
  // było zgadywać stan sesji albo próbować spina "na sucho".
  app.get('/api/discord/me', (req, res) => {
    const cookies = parseCookies(req);
    const session = getSession(cookies[SESSION_COOKIE]);
    if (!session) return res.status(401).json({ loggedIn: false });
    res.json({ loggedIn: true, username: session.username });
  });
}

module.exports = { registerDiscordAuthRoutes, SESSION_COOKIE };
