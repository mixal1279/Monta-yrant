// Serwerowe potwierdzenia CashBill. Nie oznaczamy zamówienia jako opłaconego
// na podstawie samego callbacka: podpis + odczyt statusu transakcji + zgodność kwoty.
const { verifyNotificationSignature, isCashBillConfigured, getCashbillPayment } = require('../utils/cashbillClient');
const { getDb } = require('../database/db');
const { logEvent } = require('../utils/logger');

const PAID_STATUS = 'PositiveFinish';

async function confirmCashbillPaid(client, orderId, payment) {
  const db = getDb();
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(Number(orderId));
  if (!order) throw new Error('Nie znaleziono zamówienia.');
  if (order.status === 'paid' || order.status === 'in_progress') return order;
  if (!payment || payment.status !== PAID_STATUS) throw new Error('Transakcja CashBill nie jest opłacona.');
  if (payment.currency && payment.currency !== 'PLN') throw new Error('Nieprawidłowa waluta płatności.');
  if (payment.amount != null && Math.abs(Number(payment.amount) - Number(order.total_price)) > 0.01) {
    throw new Error('Kwota płatności CashBill nie zgadza się z zamówieniem.');
  }
  const now = new Date().toISOString();
  const result = db.prepare(`UPDATE orders SET status = 'paid', payment_method = 'cashbill', updated_at = ? WHERE id = ? AND status = 'pending_payment'`).run(now, order.id);
  if (result.changes) {
    await logEvent(client, order.guild_id, 'platnosc', `CashBill potwierdził płatność zamówienia #${order.id}.`).catch(() => {});
  }
  return db.prepare('SELECT * FROM orders WHERE id = ?').get(order.id);
}

function parseNotificationArgs(args) {
  const parts = String(args || '').split(',').map((x) => x.trim());
  return { transactionId: parts[0] || null, status: parts[1] || null };
}

function registerCashBillRoutes(app, client) {
  app.get('/cashbill/notification', async (req, res) => {
    const { cmd, args = '', sign } = req.query;
    if (!isCashBillConfigured() || !verifyNotificationSignature(cmd, args, sign)) return res.status(403).send('FORBIDDEN');
    if (cmd !== 'transactionStatusChanged') return res.status(200).send('OK');

    const { transactionId, status } = parseNotificationArgs(args);
    if (!transactionId) return res.status(400).send('BAD REQUEST');

    const db = getDb();
    const order = db.prepare('SELECT * FROM orders WHERE cashbill_transaction_id = ?').get(transactionId);
    if (!order) return res.status(200).send('OK'); // podpis jest poprawny, ale transakcja może dotyczyć starego/usuniętego zamówienia

    try {
      // Status z callbacka jest tylko wskazówką; stan i kwotę potwierdzamy w API.
      const payment = await getCashbillPayment(transactionId);
      if (status === PAID_STATUS || payment.status === PAID_STATUS) await confirmCashbillPaid(client, order.id, payment);
      else db.prepare('UPDATE orders SET updated_at = ? WHERE id = ?').run(new Date().toISOString(), order.id);
      await logEvent(client, order.guild_id, 'info', `CashBill: transakcja ${transactionId}, status ${payment.status || status || 'unknown'}, zamówienie #${order.id}.`).catch(() => {});
    } catch (err) {
      console.error('Błąd weryfikacji callbacka CashBill:', err.message);
      return res.status(500).send('RETRY');
    }
    return res.status(200).send('OK');
  });
}

module.exports = { registerCashBillRoutes, confirmCashbillPaid };
