// Serwer Express: CashBill oraz pozostałe trasy aplikacji.
const express = require('express');
const { isCashBillConfigured } = require('../utils/cashbillClient');
const { registerCashBillRoutes } = require('./cashbillServer');
const { isDiscordOAuthConfigured } = require('../utils/discordAuth');
const { registerDiscordAuthRoutes } = require('./discordAuthRoutes');
const { registerQuizRoutes } = require('./quizRoutes');
const { registerCennikRoutes } = require('./cennikRoutes');
const { registerZamowienieRoutes } = require('./zamowienieRoutes');
const { registerPanelRoutes } = require('./panelRoutes');
const { rateLimit } = require('../utils/rateLimit');

function requireSameOrigin(req, res, next) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) return next();
  const site = process.env.SITE_URL;
  if (!site) return res.status(500).json({ error: 'missing_site_url' });
  const origin = req.get('origin');
  const referer = req.get('referer');
  if (origin && origin !== site) return res.status(403).json({ error: 'bad_origin' });
  if (!origin && referer && !referer.startsWith(`${site}/`)) return res.status(403).json({ error: 'bad_origin' });
  if (!origin && !referer) return res.status(403).json({ error: 'missing_origin' });
  next();
}

function startHttpServer(client) {
  const cashbillOn = isCashBillConfigured();
  const discordOAuthOn = isDiscordOAuthConfigured();
  const app = express();
  const port = process.env.WEBHOOK_PORT || 8443;

  app.disable('x-powered-by');
  app.set('etag', false);
  app.use(express.json({ limit: '64kb' }));
  app.use(express.urlencoded({ extended: false, limit: '16kb' }));

  // Security headers. CSP jest ustawiane przez statyczny hosting; API nie renderuje UI.
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    next();
  });

  if (cashbillOn) registerCashBillRoutes(app, client);
  else console.warn('⚠️ CashBill nie jest kompletnie skonfigurowany — płatności online wyłączone.');

  if (process.env.SITE_URL) {
    app.use((req, res, next) => {
      res.header('Access-Control-Allow-Origin', process.env.SITE_URL);
      res.header('Access-Control-Allow-Credentials', 'true');
      res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      res.header('Access-Control-Allow-Headers', 'Content-Type');
      res.header('Vary', 'Origin');
      if (req.method === 'OPTIONS') return res.sendStatus(204);
      next();
    });
  }

  // Ogólny limiter + dodatkowa ochrona przed CSRF dla operacji zmieniających stan.
  app.use(rateLimit({ windowMs: 60_000, max: 120 }));
  app.use(requireSameOrigin);

  registerCennikRoutes(app);
  registerZamowienieRoutes(app, client);
  registerPanelRoutes(app, client);

  if (discordOAuthOn) {
    registerDiscordAuthRoutes(app);
    registerQuizRoutes(app, client);
  } else console.warn('⚠️ Discord OAuth nieskonfigurowany — quiz wyłączony.');

  app.use((err, req, res, next) => {
    console.error('Nieobsłużony błąd HTTP:', err);
    if (res.headersSent) return next(err);
    return res.status(500).json({ error: 'internal_error', message: 'Wystąpił nieoczekiwany błąd.' });
  });

  app.listen(port, () => console.log(`🌐 Serwer HTTP nasłuchuje na porcie ${port}`));
  return app;
}

module.exports = { startHttpServer };
