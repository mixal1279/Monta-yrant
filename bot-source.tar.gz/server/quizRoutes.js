// server/quizRoutes.js
// Quiz wiedzy: wynik zależy wyłącznie od odpowiedzi użytkownika, nie od losowania.
const { generateDiscountCode, findExistingCodeFromSource } = require('../utils/discountCodes');
const { logEvent } = require('../utils/logger');
const { getSession } = require('../utils/discordSessionStore');
const { parseCookies } = require('../utils/cookies');
const { SESSION_COOKIE } = require('./discordAuthRoutes');

const GUILD_ID = process.env.GUILD_ID;
const SOURCE = 'knowledge_quiz';
const { rateLimit } = require('../utils/rateLimit');

const QUESTIONS = [
  { id: 1, text: 'Jaki format obrazu jest najczęściej używany w Shorts i Reels?', options: ['16:9', '9:16', '4:3', '1:1'], answer: 1 },
  { id: 2, text: 'Co oznacza skrót FPS w materiale wideo?', options: ['Liczbę klatek na sekundę', 'Format pliku', 'Poziom głośności', 'Rozdzielczość'], answer: 0 },
  { id: 3, text: 'Po co stosuje się napisy w shortach?', options: ['Tylko do ozdoby', 'Ułatwiają odbiór bez dźwięku', 'Zmniejszają plik', 'Zastępują montaż'], answer: 1 },
  { id: 4, text: 'Które cięcie usuwa niepotrzebną ciszę?', options: ['Jump cut', 'Fade out', 'Match cut', 'L-cut'], answer: 0 },
  { id: 5, text: 'Co zwykle powinno wydarzyć się w pierwszych sekundach shorta?', options: ['Długi ekran tytułowy', 'Mocny hook', 'Napisy końcowe', 'Czarna plansza'], answer: 1 },
  { id: 6, text: 'Który format jest typowy dla filmu z przezroczystością?', options: ['PNG', 'MP3', 'TXT', 'WAV'], answer: 0 },
  { id: 7, text: 'Co robi normalizacja dźwięku?', options: ['Wyrównuje poziom głośności', 'Zmienia proporcje obrazu', 'Dodaje napisy', 'Usuwa klatki'], answer: 0 },
  { id: 8, text: 'Czym jest B-roll?', options: ['Ujęciem uzupełniającym', 'Błędem renderowania', 'Rodzajem mikrofonu', 'Plikiem projektu'], answer: 0 },
  { id: 9, text: 'Który element pomaga utrzymać uwagę widza?', options: ['Dynamiczne tempo', 'Długie przerwy', 'Brak kontrastu', 'Powtarzanie tej samej klatki'], answer: 0 },
  { id: 10, text: 'Co oznacza eksport materiału?', options: ['Zapis gotowego filmu do pliku', 'Usunięcie projektu', 'Nagranie głosu', 'Logowanie do programu'], answer: 0 },
  { id: 11, text: 'Który kodek jest często używany przy eksporcie MP4?', options: ['H.264', 'HTML', 'JPEG', 'ZIP'], answer: 0 },
  { id: 12, text: 'Do czego służy keyframe?', options: ['Do animowania parametrów w czasie', 'Do logowania', 'Do kompresji ZIP', 'Do zmiany nazwy pliku'], answer: 0 },
  { id: 13, text: 'Co poprawia czytelność napisów?', options: ['Kontrast i odpowiedni rozmiar', 'Bardzo mały font', 'Ten sam kolor co tło', 'Brak marginesów'], answer: 0 },
  { id: 14, text: 'Czym jest timeline na osi montażowej?', options: ['Miejscem układania klipów w czasie', 'Listą klientów', 'Ustawieniem kamery', 'Formatem dźwięku'], answer: 0 },
  { id: 15, text: 'Co oznacza skrót VOD?', options: ['Video on Demand', 'Very Old Download', 'Voice Over Design', 'Video Output Data'], answer: 0 },
  { id: 16, text: 'Po co stosuje się sound design?', options: ['Buduje rytm i emocje', 'Zmniejsza rozdzielczość', 'Tworzy konto', 'Usuwa kolor'], answer: 0 },
  { id: 17, text: 'Co może oznaczać clipping w dźwięku?', options: ['Przesterowanie sygnału', 'Brak obrazu', 'Zły format napisów', 'Pusty folder'], answer: 0 },
  { id: 18, text: 'Jaki jest podstawowy cel korekcji kolorów?', options: ['Spójny i poprawny wygląd obrazu', 'Dodanie hasła', 'Zmiana FPS audio', 'Usunięcie ścieżki'], answer: 0 },
  { id: 19, text: 'Co to jest aspect ratio?', options: ['Proporcja szerokości do wysokości', 'Głośność filmu', 'Długość renderu', 'Nazwa kodeka'], answer: 0 },
  { id: 20, text: 'Dlaczego warto pracować na kopii materiału źródłowego?', options: ['Chroni oryginalne pliki', 'Zwiększa FPS', 'Dodaje napisy', 'Włącza kamerę'], answer: 0 },
  { id: 21, text: 'Co zwykle oznacza CTA w materiale?', options: ['Wezwanie do działania', 'Format audio', 'Rodzaj przejścia', 'Korekcję barwną'], answer: 0 },
  { id: 22, text: 'Który dźwięk może podkreślić moment cięcia?', options: ['Efekt whoosh lub hit', 'Cisza z usuniętej ścieżki', 'Plik tekstowy', 'Miniatura'], answer: 0 },
  { id: 23, text: 'Co daje bezpieczny margines napisów?', options: ['Zmniejsza ryzyko zasłonięcia przez interfejs aplikacji', 'Zwiększa liczbę klatek', 'Usuwa tło', 'Zmienia konto'], answer: 0 },
  { id: 24, text: 'Co warto sprawdzić przed publikacją shorta?', options: ['Obraz, dźwięk, napisy i format', 'Tylko nazwę pliku', 'Wyłącznie długość hasła', 'Nic'], answer: 0 },
  { id: 25, text: 'Jaki jest sens montażu shorta?', options: ['Szybko i jasno przekazać najlepszy moment', 'Maksymalnie wydłużyć materiał', 'Usunąć cały dźwięk', 'Ukryć najważniejszą scenę'], answer: 0 },
];

function publicQuestions() {
  return QUESTIONS.map(({ id, text, options }) => ({ id, text, options }));
}

function getSessionFromRequest(req) {
  const cookies = parseCookies(req);
  return getSession(cookies[SESSION_COOKIE]);
}

function registerQuizRoutes(app, client) {
  app.get('/api/quiz/questions', (req, res) => {
    if (!getSessionFromRequest(req)) return res.status(401).json({ error: 'not_logged_in' });
    res.json({ questions: publicQuestions() });
  });

  app.post('/api/quiz/submit', rateLimit({ windowMs: 10 * 60_000, max: 3, keyGenerator: (req) => { const s = getSessionFromRequest(req); return s?.discordId || req.ip || 'unknown'; } }), async (req, res) => {
    if (!GUILD_ID) return res.status(500).json({ error: 'missing_guild_id' });
    const session = getSessionFromRequest(req);
    if (!session) return res.status(401).json({ error: 'not_logged_in' });
    const discordId = session.discordId;
    const answers = Array.isArray(req.body?.answers) ? req.body.answers : [];
    if (answers.length !== QUESTIONS.length || answers.some((value) => !Number.isInteger(value) || value < 0 || value > 3)) {
      return res.status(400).json({ error: 'invalid_answers' });
    }

    const score = answers.reduce((sum, answer, index) => sum + (answer === QUESTIONS[index].answer ? 1 : 0), 0);
    const { getDb } = require('../database/db');
    let code;
    try {
      code = getDb().transaction(() => {
        if (findExistingCodeFromSource(GUILD_ID, discordId, SOURCE)) throw new Error('already_completed');
        return generateDiscountCode({ guildId: GUILD_ID, userId: discordId, discountType: 'percent', discountValue: score, maxUses: 1, source: SOURCE, prefix: 'QUIZ' });
      })();
    } catch (err) {
      if (err.message === 'already_completed' || err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
        return res.status(409).json({ error: 'already_completed', message: 'Quiz został już rozwiązany na tym koncie Discord.' });
      }
      throw err;
    }

    await logEvent(client, GUILD_ID, 'info', `🧠 Quiz: wynik ${score}/25, kod ${code} dla <@${discordId}>.`).catch(() => {});
    res.json({ score, total: QUESTIONS.length, discountPercent: score, code, discordUsername: session.username });
  });
}

module.exports = { registerQuizRoutes };
