const { getSession } = require('../utils/discordSessionStore');
const { parseCookies } = require('../utils/cookies');
const { SESSION_COOKIE } = require('./discordAuthRoutes');
const { getConfig } = require('../config/config');
const { getOrderDetails, listOrders, setOrderStatus, LABELS } = require('../utils/orderService');

function session(req) { return getSession(parseCookies(req)[SESSION_COOKIE]); }

async function staff(req, client) {
  const s = session(req);
  if (!s) return null;
  const guild = client.guilds.cache.get(process.env.GUILD_ID);
  if (!guild) return null;
  const member = await guild.members.fetch(s.discordId).catch(() => null);
  if (!member) return null;
  const cfg = getConfig(guild.id);
  const ok = member.permissions.has('Administrator') || member.roles.cache.has(cfg?.staff_role_id) || member.roles.cache.has(cfg?.admin_role_id);
  return ok ? { session: s, guild, member, cfg } : null;
}

function noStore(res) { res.setHeader('Cache-Control', 'no-store'); }

function registerPanelRoutes(app, client) {
  app.get('/api/panel/me', async (req,res) => {
    noStore(res);
    const auth = await staff(req, client);
    if (!auth) return res.status(403).json({ authenticated:false });
    res.json({ authenticated:true, username:auth.session.username, userId:auth.session.discordId });
  });

  app.get('/api/panel/orders', async (req,res) => {
    noStore(res);
    const auth = await staff(req, client);
    if (!auth) return res.status(403).json({ error:'forbidden' });
    const data = listOrders({ guildId: auth.guild.id, status:req.query.status, search:req.query.search, limit:req.query.limit, offset:req.query.offset });
    res.json({ ...data, statuses: LABELS });
  });

  app.get('/api/panel/orders/:id', async (req,res) => {
    noStore(res);
    const auth = await staff(req, client);
    if (!auth) return res.status(403).json({ error:'forbidden' });
    const order = getOrderDetails(req.params.id, auth.guild.id);
    if (!order) return res.status(404).json({ error:'not_found' });
    res.json(order);
  });

  app.post('/api/panel/orders/:id/status', async (req,res) => {
    noStore(res);
    const auth = await staff(req, client);
    if (!auth) return res.status(403).json({ error:'forbidden' });
    try {
      const order = await setOrderStatus(client, req.params.id, req.body?.status, auth.session.discordId);
      res.json({ ok:true, order });
    } catch (e) { res.status(400).json({ error:'invalid_status', message:e.message }); }
  });
}
module.exports = { registerPanelRoutes };
