// database/db.js
// Warstwa dostępu do bazy danych SQLite (better-sqlite3, synchroniczne zapytania).
// Eksportuje singleton połączenia + funkcję reconnect() używaną przy /backup restore.

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'bot.db');

let db = null;

function ensureDir(filePath) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function applySchema(database) {
  database.pragma('journal_mode = WAL');
  database.exec(`
    CREATE TABLE IF NOT EXISTS config (
      guild_id TEXT PRIMARY KEY,
      orders_channel_id TEXT,
      logs_channel_id TEXT,
      portfolio_channel_id TEXT,
      pricing_channel_id TEXT,
      ticket_category_id TEXT,
      admin_role_id TEXT,
      staff_role_id TEXT,
      orders_notifications_channel_id TEXT,
      reviews_channel_id TEXT,
      pricing_message_id TEXT,
      pricing_message_channel_id TEXT
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      package_key TEXT NOT NULL,
      package_name TEXT NOT NULL,
      is_bulk INTEGER DEFAULT 0,
      base_price INTEGER NOT NULL,
      addons TEXT DEFAULT '[]',
      addons_price INTEGER DEFAULT 0,
      game TEXT,
      materials_type TEXT,
      materials_link TEXT,
      search_fee INTEGER DEFAULT 0,
      has_timestamps TEXT,
      notes TEXT,
      total_price INTEGER NOT NULL,
      discount_code TEXT,
      discount_amount INTEGER DEFAULT 0,
      status TEXT DEFAULT 'pending_payment',
      payment_method TEXT,
      paypal_order_id TEXT,
      paypal_capture_id TEXT,
      cashbill_payment_id TEXT,
      cashbill_transaction_id TEXT,
      cashbill_checkout_url TEXT,
      order_token TEXT,
      ticket_channel_id TEXT,
      portfolio_consent INTEGER DEFAULT 0,
      refunded INTEGER DEFAULT 0,
      cancel_reason TEXT,
      priority_deadline TEXT,
      priority_alert_stage TEXT,
      materials_reminder_sent_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      delivered_at TEXT
    );

    CREATE TABLE IF NOT EXISTS terms_acceptance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      order_id INTEGER,
      accepted_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      user_id TEXT NOT NULL,
      package_name TEXT,
      game TEXT,
      rating INTEGER NOT NULL,
      comment TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT,
      type TEXT,
      message TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS discount_codes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT UNIQUE NOT NULL,
      guild_id TEXT NOT NULL,
      user_id TEXT,
      discount_type TEXT NOT NULL,
      discount_value REAL NOT NULL,
      max_uses INTEGER DEFAULT 1,
      uses_count INTEGER DEFAULT 0,
      active INTEGER DEFAULT 1,
      source TEXT,
      expires_at TEXT,
      created_at TEXT NOT NULL
    );
  `);
}

function migrateNewColumns(database) {
  // Lekki system migracji: próbujemy dodać kolumny, które mogły nie istnieć
  // w bazach utworzonych przed dodaniem integracji płatności. Jeśli kolumna
  // już istnieje, SQLite rzuci błąd, który po prostu ignorujemy.
  const migrations = [
    // Legacy z czasów integracji PayPal — zostawione, bo stare zamówienia
    // wciąż mają tu zapisane ID. Bot nie zapisuje już do tych kolumn.
    'ALTER TABLE orders ADD COLUMN paypal_order_id TEXT',
    'ALTER TABLE orders ADD COLUMN paypal_capture_id TEXT',
    'ALTER TABLE orders ADD COLUMN cashbill_payment_id TEXT',
    'ALTER TABLE orders ADD COLUMN cashbill_transaction_id TEXT',
    // Faza 2: finalizacja zamówienia na stronie (order_token w URL zamiast
    // zgadywalnego ID) + zapamiętany link do checkoutu, żeby nie tworzyć
    // drugiej płatności CashBill przy ponownym kliknięciu "płacę".
    'ALTER TABLE orders ADD COLUMN cashbill_checkout_url TEXT',
    'ALTER TABLE orders ADD COLUMN order_token TEXT',
    // Legacy z czasów integracji P24 — zostawione na wypadek istniejących baz,
    // same kolumny nie są już używane przez bota.
    'ALTER TABLE orders ADD COLUMN p24_session_id TEXT',
    'ALTER TABLE orders ADD COLUMN p24_order_id TEXT',
    'ALTER TABLE orders ADD COLUMN refunded INTEGER DEFAULT 0',
    'ALTER TABLE orders ADD COLUMN cancel_reason TEXT',
    'ALTER TABLE orders ADD COLUMN discount_code TEXT',
    'ALTER TABLE orders ADD COLUMN discount_amount INTEGER DEFAULT 0',
    'ALTER TABLE orders ADD COLUMN priority_deadline TEXT',
    'ALTER TABLE orders ADD COLUMN priority_alert_stage TEXT',
    'ALTER TABLE orders ADD COLUMN materials_reminder_sent_at TEXT',
    'ALTER TABLE terms_acceptance ADD COLUMN terms_version TEXT',
    'ALTER TABLE terms_acceptance ADD COLUMN privacy_version TEXT',
    'ALTER TABLE terms_acceptance ADD COLUMN withdrawal_requested INTEGER DEFAULT 0',
    'ALTER TABLE terms_acceptance ADD COLUMN withdrawal_acknowledged INTEGER DEFAULT 0',
    'ALTER TABLE terms_acceptance ADD COLUMN accepted_ip TEXT',
  ];
  for (const sql of migrations) {
    try {
      database.exec(sql);
    } catch (err) {
      // kolumna już istnieje — nic nie robimy
    }
  }
}

function connect() {
  ensureDir(DB_PATH);
  db = new Database(DB_PATH);
  applySchema(db);
  migrateNewColumns(db);
  // Indeksy bezpieczeństwa i integralności — wielokrotne wykonanie jest bezpieczne.
  db.exec(`
    CREATE INDEX IF NOT EXISTS ix_orders_cashbill_transaction ON orders(cashbill_transaction_id);
    CREATE UNIQUE INDEX IF NOT EXISTS ux_orders_order_token ON orders(order_token) WHERE order_token IS NOT NULL;
  `);
  return db;
}

function getDb() {
  if (!db) connect();
  return db;
}

// Używane przez /backup restore — zamyka aktualne połączenie, żeby
// można było bezpiecznie podmienić plik bazy na dysku, a potem otwiera je ponownie.
function closeDb() {
  if (db) {
    db.close();
    db = null;
  }
}

function reconnect() {
  closeDb();
  return connect();
}

module.exports = { getDb, closeDb, reconnect, DB_PATH };
