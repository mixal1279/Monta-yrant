# Security patch — 24.09.2026

## Naprawione w kodzie
- OAuth state jest powiązany z host-only cookie i jednorazowy.
- Rate limiting dla API, OAuth, quizu, tworzenia zamówień i płatności.
- Ochrona CSRF przez sprawdzanie Origin/Referer dla operacji zmieniających stan.
- Security headers i brak `X-Powered-By`.
- Atomowe zużywanie kodów rabatowych + transakcje SQLite dla quizu i zamówień.
- Race condition przy równoległym inicjowaniu płatności w jednym procesie.
- CashBill ma teraz fail-closed adapter, weryfikację statusu i kwoty oraz idempotency/reference.
- Webhook CashBill nie oznacza zamówienia jako opłaconego bez dodatkowej weryfikacji API.
- Path traversal w restore/delete backupów zablokowany.
- Backup SQLite wykonuje checkpoint WAL przed kopiowaniem.
- Eksport CSV neutralizuje formuły arkusza.
- Usunięto ExcelJS/XLSX z produkcyjnego flow ze względu na nieaktualne zależności i zgłaszane problemy bezpieczeństwa.
- Dodano audyt zmian statusu zamówień w logach.
- Zapisywana jest wersja regulaminu/polityki oraz zgoda na rozpoczęcie usługi przed 14 dniami.
- Dodano formularz odstąpienia.
- Poprawiono regulamin i politykę prywatności: brak uznaniowego wyłączania praw konsumenta, opis odbiorców danych, podstaw prawnych i okresów przechowywania.
- Dane produkcyjnej bazy i backupy usunięto z paczki źródłowej.

## Ręcznie przed publikacją
1. Uzupełnij prawdziwy adres i pełne dane usługodawcy w `regulamin.html` i `privacy.html`.
2. Uzupełnij `.env` zgodnie z aktualną konfiguracją CashBill (`CASHBILL_CREATE_PAYMENT_URL`, `CASHBILL_STATUS_URL_TEMPLATE`, API key itd.).
3. Ustaw HTTPS i prawidłowe domeny OAuth/API.
4. Skonfiguruj backup poza katalogiem WWW i repozytorium; najlepiej szyfrowany.
5. Zweryfikuj umowę/podstawy przetwarzania z Discord, Formspree, hostingiem i CashBill.
6. Przed sprzedażą konsumencką zweryfikuj regulamin i model działalności z prawnikiem.
