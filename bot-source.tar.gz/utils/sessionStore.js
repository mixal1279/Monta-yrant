// utils/sessionStore.js
// Trzyma stan toczących się zamówień (krok po kroku) w pamięci procesu.
// Klucz: user_id. Sesje wygasają po 15 minutach nieaktywności, żeby
// nie zaśmiecać pamięci porzuconymi flow.

const sessions = new Map();
const SESSION_TTL_MS = 15 * 60 * 1000;

function _cleanupExpired() {
  const now = Date.now();
  for (const [userId, session] of sessions.entries()) {
    if (now - session.updatedAt > SESSION_TTL_MS) {
      sessions.delete(userId);
    }
  }
}

function startSession(userId, guildId) {
  _cleanupExpired();
  const session = {
    userId,
    guildId,
    packageKey: null,
    isBulk: false,
    addons: [],
    game: null,
    materialsType: null, // 'gotowe' | 'szukaj'
    searchFeeTier: null,
    materialsLink: null,
    hasTimestamps: null, // 'tak' | 'nie'
    notes: null,
    termsAccepted: false,
    updatedAt: Date.now(),
  };
  sessions.set(userId, session);
  return session;
}

function getSession(userId) {
  const session = sessions.get(userId);
  if (!session) return null;
  if (Date.now() - session.updatedAt > SESSION_TTL_MS) {
    sessions.delete(userId);
    return null;
  }
  return session;
}

function updateSession(userId, patch) {
  const session = sessions.get(userId);
  if (!session) return null;
  Object.assign(session, patch, { updatedAt: Date.now() });
  return session;
}

function clearSession(userId) {
  sessions.delete(userId);
}

function hasActiveSession(userId) {
  return !!getSession(userId);
}

module.exports = { startSession, getSession, updateSession, clearSession, hasActiveSession };
