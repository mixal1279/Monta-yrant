// utils/priorityTracking.js
// Zamówienia z dodatkiem "Priorytet 12h" dostają deadline liczony od momentu
// opłacenia. Ten moduł: (1) ustawia deadline, gdy zamówienie staje się 'paid',
// (2) cyklicznie sprawdza zbliżające się/przekroczone deadline'y i ostrzega
// staff na kanale ticketu.

const { getDb } = require('../database/db');
const { logEvent } = require('./logger');

const PRIORITY_HOURS = Number(process.env.PRIORITY_DEADLINE_HOURS) || 12;
const WARN_BEFORE_HOURS = Number(process.env.PRIORITY_WARN_BEFORE_HOURS) || 2;

function hasPriorityAddon(order) {
  try {
    const addons = JSON.parse(order.addons || '[]');
    return addons.includes('priority');
  } catch (_) {
    return false;
  }
}

// Wołane zaraz po tym, jak status zamówienia staje się 'paid' (i z ręcznego
// przycisku w tickecie, i z automatycznego potwierdzenia Mollie).
function maybeSetPriorityDeadline(orderId) {
  const db = getDb();
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  if (!order || !hasPriorityAddon(order) || order.priority_deadline) return;

  const deadline = new Date(Date.now() + PRIORITY_HOURS * 60 * 60 * 1000).toISOString();
  db.prepare('UPDATE orders SET priority_deadline = ? WHERE id = ?').run(deadline, orderId);
}

async function checkPriorityDeadlines(client) {
  const db = getDb();
  const candidates = db
    .prepare(
      `SELECT * FROM orders
       WHERE priority_deadline IS NOT NULL
       AND status NOT IN ('delivered', 'completed', 'cancelled')`
    )
    .all();

  const now = Date.now();
  const warnThresholdMs = WARN_BEFORE_HOURS * 60 * 60 * 1000;

  for (const order of candidates) {
    const deadlineMs = new Date(order.priority_deadline).getTime();
    const remainingMs = deadlineMs - now;

    if (remainingMs <= 0 && order.priority_alert_stage !== 'breached') {
      await sendPriorityAlert(
        client,
        order,
        `🚨 **PRZEKROCZONY deadline priorytetu!** Zamówienie #${order.id} miało być gotowe <t:${Math.floor(deadlineMs / 1000)}:R>.`
      );
      db.prepare('UPDATE orders SET priority_alert_stage = ? WHERE id = ?').run('breached', order.id);
    } else if (remainingMs > 0 && remainingMs <= warnThresholdMs && !order.priority_alert_stage) {
      await sendPriorityAlert(
        client,
        order,
        `⚠️ Zostały **mniej niż ${WARN_BEFORE_HOURS}h** na deadline priorytetu zamówienia #${order.id} (<t:${Math.floor(
          deadlineMs / 1000
        )}:R>).`
      );
      db.prepare('UPDATE orders SET priority_alert_stage = ? WHERE id = ?').run('warned', order.id);
    }
  }
}

async function sendPriorityAlert(client, order, message) {
  await logEvent(client, order.guild_id, 'info', `${message} (zamówienie #${order.id})`);

  if (!order.ticket_channel_id) return;
  try {
    const channel = await client.channels.fetch(order.ticket_channel_id);
    await channel.send(message);
  } catch (_) {
    // kanał ticketu mógł zostać usunięty — log wyżej i tak już poszedł
  }
}

module.exports = { maybeSetPriorityDeadline, checkPriorityDeadlines, PRIORITY_HOURS, WARN_BEFORE_HOURS };
