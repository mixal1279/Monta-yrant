// utils/backupManager.js
// Backup polega na skopiowaniu pliku bazy SQLite do folderu /backups z timestampem
// w nazwie. Trzymane jest maksymalnie 7 najnowszych plików — starsze są usuwane.

const fs = require('fs');
const path = require('path');
const { DB_PATH, reconnect, getDb } = require('../database/db');

const BACKUP_DIR = path.join(__dirname, '..', 'backups');
const MAX_BACKUPS = 7;

function ensureBackupDir() {
  if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

function timestampForFilename() {
  const d = new Date();
  const pad = (n, len = 2) => String(n).padStart(len, '0');
  // Milisekundy na końcu — zapobiega nadpisywaniu backupów tworzonych
  // w obrębie tej samej sekundy (np. ręczny backup tuż po automatycznym).
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(
    d.getHours()
  )}-${pad(d.getMinutes())}-${pad(d.getSeconds())}-${pad(d.getMilliseconds(), 3)}`;
}

function safeBackupPath(filename) {
  if (typeof filename !== 'string' || !/^[A-Za-z0-9_.-]+\.db$/.test(filename)) throw new Error('Nieprawidłowa nazwa backupu.');
  const base = path.resolve(BACKUP_DIR);
  const resolved = path.resolve(BACKUP_DIR, filename);
  if (!resolved.startsWith(base + path.sep)) throw new Error('Nieprawidłowa ścieżka backupu.');
  return resolved;
}

function createBackup() {
  ensureBackupDir();
  if (!fs.existsSync(DB_PATH)) {
    throw new Error('Plik bazy danych nie istnieje — nie ma czego backupować.');
  }

  let filename = `backup_${timestampForFilename()}.db`;
  let destination = path.join(BACKUP_DIR, filename);

  // Dodatkowe zabezpieczenie: gdyby mimo milisekundowej precyzji nazwa już
  // istniała (np. backupy tworzone w pętli/testach), dolicz licznik.
  let counter = 1;
  while (fs.existsSync(destination)) {
    filename = `backup_${timestampForFilename()}_${counter}.db`;
    destination = path.join(BACKUP_DIR, filename);
    counter += 1;
  }

  // better-sqlite3 korzysta z WAL; checkpoint przed kopiowaniem zapobiega
  // backupowi starszemu niż ostatnie transakcje zapisane do .db-wal.
  getDb().pragma('wal_checkpoint(TRUNCATE)');
  fs.copyFileSync(DB_PATH, destination);

  pruneOldBackups();

  return filename;
}

function pruneOldBackups() {
  const files = listBackups();
  if (files.length <= MAX_BACKUPS) return;

  const toDelete = files.slice(MAX_BACKUPS); // listBackups jest posortowane od najnowszych
  for (const file of toDelete) {
    fs.unlinkSync(path.join(BACKUP_DIR, file.name));
  }
}

function listBackups() {
  ensureBackupDir();
  return fs
    .readdirSync(BACKUP_DIR)
    .filter((f) => f.endsWith('.db'))
    .map((name) => {
      const stat = fs.statSync(path.join(BACKUP_DIR, name));
      return { name, size: stat.size, mtime: stat.mtimeMs };
    })
    .sort((a, b) => b.mtime - a.mtime);
}

function restoreBackup(filename) {
  const filePath = safeBackupPath(filename);
  if (!fs.existsSync(filePath)) {
    throw new Error(`Backup "${filename}" nie istnieje.`);
  }

  // Bezpieczna podmiana: najpierw zamknij aktualne połączenie do bazy,
  // dopiero potem nadpisz plik, na końcu otwórz połączenie ponownie.
  const { closeDb } = require('../database/db');
  closeDb();
  fs.copyFileSync(filePath, DB_PATH);
  reconnect();
}

function deleteBackup(filename) {
  const filePath = safeBackupPath(filename);
  if (!fs.existsSync(filePath)) {
    throw new Error(`Backup "${filename}" nie istnieje.`);
  }
  fs.unlinkSync(filePath);
}

module.exports = { createBackup, listBackups, restoreBackup, deleteBackup, BACKUP_DIR, MAX_BACKUPS };
