// utils/logger.js
// Centralne logowanie: zapis do tabeli logs + wysyłka embedu na kanał logów (jeśli skonfigurowany).

const { EmbedBuilder } = require('discord.js');
const { getDb } = require('../database/db');
const { getConfig } = require('../config/config');

const TYPE_COLORS = {
  zamowienie: 0x5865f2,
  platnosc: 0x57f287,
  anulowanie: 0xed4245,
  ukonczenie: 0x57f287,
  backup: 0xfee75c,
  blad: 0xed4245,
  info: 0x99aab5,
};

async function logEvent(client, guildId, type, message) {
  try {
    const db = getDb();
    db.prepare(
      'INSERT INTO logs (guild_id, type, message, created_at) VALUES (?, ?, ?, ?)'
    ).run(guildId, type, message, new Date().toISOString());

    const cfg = getConfig(guildId);
    if (!cfg || !cfg.logs_channel_id || !client) return;

    const channel = await client.channels.fetch(cfg.logs_channel_id).catch(() => null);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor(TYPE_COLORS[type] || TYPE_COLORS.info)
      .setDescription(message)
      .setFooter({ text: type.toUpperCase() })
      .setTimestamp();

    await channel.send({ embeds: [embed] }).catch(() => {});
  } catch (err) {
    console.error('[logger] Błąd logowania:', err);
  }
}

module.exports = { logEvent };
