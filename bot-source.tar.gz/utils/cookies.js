// utils/cookies.js
// Celowo minimalne — potrzebujemy obsłużyć dokładnie jedno cookie sesji
// logowania Discord, więc zamiast dokładać zależność (cookie-parser) piszemy
// to ręcznie w kilkunastu liniach.

function parseCookies(req) {
  const header = req.headers.cookie;
  const out = {};
  if (!header) return out;
  for (const pair of header.split(';')) {
    const idx = pair.indexOf('=');
    if (idx === -1) continue;
    const key = pair.slice(0, idx).trim();
    const val = pair.slice(idx + 1).trim();
    if (key) out[key] = decodeURIComponent(val);
  }
  return out;
}

// SameSite=Lax (+ Secure) — strona (montazyrant.pl) i API (api.montazyrant.pl)
// to teraz subdomeny tej samej domeny, więc dla przeglądarki to "same-site".
// Lax w pełni wystarcza i jest bezpieczniejszy niż None — a przy okazji
// naprawia logowanie w przeglądarkach, które blokują cookie SameSite=None
// pochodzące z domeny trzeciej strony (np. workers.dev), jak Safari czy Firefox.
// WAŻNE: ustaw SITE_COOKIE_DOMAIN=.montazyrant.pl w .env, żeby cookie
// wystawione na api.montazyrant.pl było widoczne też dla montazyrant.pl.
function setCookie(res, name, value, maxAgeMs, options = {}) {
  const parts = [
    `${name}=${encodeURIComponent(value)}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    'Secure',
    `Max-Age=${Math.floor(maxAgeMs / 1000)}`,
  ];
  if (options.domain !== false && process.env.SITE_COOKIE_DOMAIN) parts.push(`Domain=${process.env.SITE_COOKIE_DOMAIN}`);
  res.append('Set-Cookie', parts.join('; '));
}

function clearCookie(res, name, options = {}) {
  const parts = [`${name}=`, 'Path=/', 'HttpOnly', 'SameSite=Lax', 'Secure', 'Max-Age=0'];
  if (options.domain !== false && process.env.SITE_COOKIE_DOMAIN) parts.push(`Domain=${process.env.SITE_COOKIE_DOMAIN}`);
  res.append('Set-Cookie', parts.join('; '));
}

module.exports = { parseCookies, setCookie, clearCookie };
