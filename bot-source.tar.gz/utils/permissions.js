// utils/permissions.js
// Wspólna logika sprawdzania, czy dany member to staff/admin bota —
// używana przez przyciski statusu ticketu oraz komendy /refund i /platnosc.

function isStaffMember(member, cfg) {
  if (!member || !cfg) return false;
  return (
    member.permissions.has('Administrator') ||
    (cfg.staff_role_id && member.roles.cache.has(cfg.staff_role_id)) ||
    (cfg.admin_role_id && member.roles.cache.has(cfg.admin_role_id))
  );
}

module.exports = { isStaffMember };
