// utils/exportData.js
// Bezpieczny eksport zamówień/opinii do CSV.
// Pliki zapisywane są tymczasowo do /backups/../exports i zwracane jako ścieżka,
// żeby można je było dołączyć do odpowiedzi interakcji jako załącznik.

const fs = require('fs');
const path = require('path');
const { getDb } = require('../database/db');

const EXPORT_DIR = path.join(__dirname, '..', 'backups', 'exports');

function ensureExportDir() {
  if (!fs.existsSync(EXPORT_DIR)) fs.mkdirSync(EXPORT_DIR, { recursive: true });
}

function csvEscape(value) {
  let str = value === null || value === undefined ? '' : String(value);
  if (/^[=+\-@]/.test(str)) str = `'${str}`;
  if (str.includes(';') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function buildCsv(rows, columns) {
  const header = columns.map((c) => csvEscape(c.label)).join(';');
  const lines = rows.map((row) => columns.map((c) => csvEscape(row[c.key])).join(';'));
  return [header, ...lines].join('\n');
}

const ORDER_COLUMNS = [
  { key: 'id', label: 'ID' },
  { key: 'user_id', label: 'Klient (ID)' },
  { key: 'package_name', label: 'Pakiet' },
  { key: 'game', label: 'Gra' },
  { key: 'total_price', label: 'Cena (zł)' },
  { key: 'discount_code', label: 'Kod rabatowy' },
  { key: 'discount_amount', label: 'Rabat (zł)' },
  { key: 'status', label: 'Status' },
  { key: 'payment_method', label: 'Metoda płatności' },
  { key: 'refunded', label: 'Zwrócone' },
  { key: 'cancel_reason', label: 'Powód anulowania/zwrotu' },
  { key: 'materials_type', label: 'Typ materiałów' },
  { key: 'created_at', label: 'Utworzono' },
  { key: 'delivered_at', label: 'Dostarczono' },
];

const REVIEW_COLUMNS = [
  { key: 'id', label: 'ID' },
  { key: 'order_id', label: 'ID zamówienia' },
  { key: 'user_id', label: 'Klient (ID)' },
  { key: 'package_name', label: 'Pakiet' },
  { key: 'game', label: 'Gra' },
  { key: 'rating', label: 'Ocena' },
  { key: 'comment', label: 'Komentarz' },
  { key: 'created_at', label: 'Data' },
];

async function exportOrders(guildId, format) {
  ensureExportDir();
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM orders WHERE guild_id = ? ORDER BY id DESC')
    .all(guildId);

  return _writeExport(rows, ORDER_COLUMNS, 'zamowienia', format);
}

async function exportReviews(guildId, format) {
  ensureExportDir();
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT r.* FROM reviews r
       JOIN orders o ON o.id = r.order_id
       WHERE o.guild_id = ?
       ORDER BY r.id DESC`
    )
    .all(guildId);

  return _writeExport(rows, REVIEW_COLUMNS, 'opinie', format);
}

async function _writeExport(rows, columns, baseName, format) {
  const ts = Date.now();
  if (format === 'xlsx') throw new Error('Eksport XLSX jest tymczasowo wyłączony ze względów bezpieczeństwa zależności. Użyj CSV.');

  const filePath = path.join(EXPORT_DIR, `${baseName}_${ts}.csv`);
  const csv = buildCsv(rows, columns);
  fs.writeFileSync(filePath, '\uFEFF' + csv, 'utf8'); // BOM dla poprawnych polskich znaków w Excelu
  return filePath;
}

function monthlyReport(guildId, year, month) {
  const db = getDb();

  // month: 1-12
  const start = new Date(year, month - 1, 1).toISOString();
  const end = new Date(year, month, 1).toISOString();

  const orders = db
    .prepare(
      `SELECT * FROM orders WHERE guild_id = ? AND created_at >= ? AND created_at < ?`
    )
    .all(guildId, start, end);

  const completed = orders.filter((o) => o.status === 'completed' || o.status === 'delivered');
  const revenue = orders
    .filter((o) => !['pending_payment', 'cancelled'].includes(o.status))
    .reduce((sum, o) => sum + o.total_price, 0);

  const reviews = db
    .prepare(
      `SELECT r.rating FROM reviews r
       JOIN orders o ON o.id = r.order_id
       WHERE o.guild_id = ? AND r.created_at >= ? AND r.created_at < ?`
    )
    .all(guildId, start, end);

  const avgRating =
    reviews.length > 0
      ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(2)
      : null;

  const topPackage = _mostCommon(orders.map((o) => o.package_name));
  const topGame = _mostCommon(orders.map((o) => o.game));

  return {
    orderCount: orders.length,
    completedCount: completed.length,
    revenue,
    avgRating,
    reviewCount: reviews.length,
    topPackage,
    topGame,
  };
}

function overallStats(guildId) {
  const db = getDb();
  const orders = db.prepare('SELECT * FROM orders WHERE guild_id = ?').all(guildId);
  const revenue = orders
    .filter((o) => !['pending_payment', 'cancelled'].includes(o.status))
    .reduce((sum, o) => sum + o.total_price, 0);

  const reviews = db
    .prepare(
      `SELECT r.rating FROM reviews r JOIN orders o ON o.id = r.order_id WHERE o.guild_id = ?`
    )
    .all(guildId);

  const avgRating =
    reviews.length > 0
      ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(2)
      : null;

  return {
    orderCount: orders.length,
    revenue,
    avgRating,
    reviewCount: reviews.length,
    topPackage: _mostCommon(orders.map((o) => o.package_name)),
    topGame: _mostCommon(orders.map((o) => o.game)),
  };
}

function _mostCommon(arr) {
  const filtered = arr.filter(Boolean);
  if (filtered.length === 0) return '—';
  const counts = {};
  for (const item of filtered) counts[item] = (counts[item] || 0) + 1;
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
}

module.exports = { exportOrders, exportReviews, monthlyReport, overallStats, EXPORT_DIR };
