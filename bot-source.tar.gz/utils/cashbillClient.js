// CashBill adapter. Integracja jest fail-closed: płatności są uznawane za
// skonfigurowane dopiero wtedy, gdy aplikacja ma endpoint tworzenia płatności,
// endpoint odczytu statusu i klucz API. Adresy/metody zależą od konfiguracji
// Punktu Płatności w CashBill — sprawdź aktualną dokumentację operatora.
const crypto = require('crypto');

function getCashBillConfig() {
  return {
    paymentPointId: process.env.CASHBILL_PAYMENT_POINT_ID || '',
    secretKey: process.env.CASHBILL_SECRET_KEY || '',
    apiKey: process.env.CASHBILL_API_KEY || '',
    notificationUrl: process.env.CASHBILL_NOTIFICATION_URL || '',
    createPaymentUrl: process.env.CASHBILL_CREATE_PAYMENT_URL || '',
    statusUrlTemplate: process.env.CASHBILL_STATUS_URL_TEMPLATE || '',
  };
}

function isCashBillConfigured() {
  const c = getCashBillConfig();
  return Boolean(c.paymentPointId && c.secretKey && c.apiKey && c.notificationUrl && c.createPaymentUrl && c.statusUrlTemplate);
}

function verifyNotificationSignature(cmd, args, sign, secretKey = getCashBillConfig().secretKey) {
  if (!cmd || typeof args !== 'string' || !sign || !secretKey) return false;
  const expected = crypto.createHash('md5').update(`${cmd}${args}${secretKey}`, 'utf8').digest('hex');
  const received = String(sign).toLowerCase();
  if (!/^[a-f0-9]+$/.test(received) || received.length !== expected.length) return false;
  return crypto.timingSafeEqual(Buffer.from(received, 'hex'), Buffer.from(expected, 'hex'));
}

async function cashbillFetch(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      Accept: 'application/json',
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      Authorization: `Bearer ${getCashBillConfig().apiKey}`,
      ...(options.headers || {}),
    },
    signal: AbortSignal.timeout(10000),
  });
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (_) { data = { raw: text }; }
  if (!res.ok) throw new Error(`CashBill API HTTP ${res.status}`);
  return data;
}

async function createCashbillPayment(order) {
  const c = getCashBillConfig();
  if (!isCashBillConfigured()) throw new Error('CashBill API nie jest kompletnie skonfigurowane.');
  const payload = {
    shopId: c.paymentPointId,
    amount: Number(order.total_price).toFixed(2),
    title: `MontaŻyrant — zamówienie #${order.id}`,
    description: order.package_name,
    reference: `montazyrant:${order.id}`,
    orderId: String(order.id),
    idempotencyKey: `montazyrant-order-${order.id}`,
    externalId: String(order.id),
    notificationUrl: c.notificationUrl,
  };
  const data = await cashbillFetch(c.createPaymentUrl, { method: 'POST', body: JSON.stringify(payload) });
  const paymentId = data?.paymentId ?? data?.transactionId ?? data?.id ?? data?.transaction?.id;
  const checkoutUrl = data?.checkoutUrl ?? data?.paymentUrl ?? data?.url ?? data?.transaction?.url;
  if (!paymentId || !checkoutUrl) throw new Error('CashBill API zwróciło odpowiedź bez ID transakcji lub URL płatności.');
  return { paymentId: String(paymentId), checkoutUrl: String(checkoutUrl) };
}

async function getCashbillPayment(paymentId) {
  const c = getCashBillConfig();
  if (!c.apiKey || !c.statusUrlTemplate) throw new Error('Brak konfiguracji statusu CashBill.');
  const url = c.statusUrlTemplate.replace('{paymentId}', encodeURIComponent(String(paymentId))).replace('{transactionId}', encodeURIComponent(String(paymentId)));
  const data = await cashbillFetch(url, { method: 'GET' });
  const payment = data?.payment || data?.transaction || data;
  return {
    paymentId: String(payment?.paymentId ?? payment?.transactionId ?? payment?.id ?? paymentId),
    status: payment?.status ?? payment?.transactionStatus ?? null,
    amount: payment?.amount != null ? Number(payment.amount) : null,
    currency: payment?.currency ?? 'PLN',
  };
}

module.exports = { getCashBillConfig, isCashBillConfigured, verifyNotificationSignature, createCashbillPayment, getCashbillPayment };
