// utils/oauthStateStore.js
// Krótkotrwałe, jednorazowe powiązanie losowego "state" z konkretnym Discord
// userem/serwerem. Dwa cele: (1) wiemy, komu przypisać wynik po powrocie
// z ekranu zgody Google, (2) zabezpieczenie przed CSRF — bez tego ktoś mógłby
// podesłać cudzy link callback i podszyć się pod inną osobę.

const crypto = require('crypto');

const states = new Map(); // state -> { userId, guildId, extra, createdAt }
const TTL_MS = 10 * 60 * 1000;

function _cleanupExpired() {
  const now = Date.now();
  for (const [state, data] of states.entries()) {
    if (now - data.createdAt > TTL_MS) states.delete(state);
  }
}

// `extra` to dowolna dodatkowa dana do odzyskania po powrocie z OAuth (np.
// ścieżka powrotu na stronie) — opcjonalne, domyślnie null, nie zmienia
// zachowania istniejących wywołań z dwoma argumentami.
function createState(userId, guildId, extra = null) {
  _cleanupExpired();
  const state = crypto.randomBytes(16).toString('hex');
  states.set(state, { userId, guildId, extra, createdAt: Date.now() });
  return state;
}

// Jednorazowe — od razu usuwa state z mapy, żeby link nie dało się użyć dwa razy.
function consumeState(state) {
  const data = states.get(state);
  if (!data) return null;
  states.delete(state);
  if (Date.now() - data.createdAt > TTL_MS) return null;
  return data;
}

module.exports = { createState, consumeState };
