// utils/materialsReminder.js
// Zamówienia utknięte w statusie 'waiting_for_materials' dostają cykliczne
// przypomnienie (DM do klienta + wiadomość w tickecie), żeby nic nie ginęło
// w martwym punkcie. W przeciwieństwie do auto-anulowania (orderCleanup.js)
// te zamówienia są już opłacone, więc nie anulujemy — tylko ponaglamy.

const { getDb } = require('../database/db');
const { logEvent } = require('./logger');

const REMINDER_HOURS = Number(process.env.MATERIALS_REMINDER_HOURS) || 48;

async function sendMaterialsReminders(client) {
  const db = getDb();
  const cutoff = new Date(Date.now() - REMINDER_HOURS * 60 * 60 * 1000).toISOString();

  const candidates = db
    .prepare(
      `SELECT * FROM orders
       WHERE status = 'waiting_for_materials'
       AND (materials_reminder_sent_at IS NULL OR materials_reminder_sent_at < ?)
       AND updated_at < ?`
    )
    .all(cutoff, cutoff);

  if (candidates.length === 0) return 0;

  const now = new Date().toISOString();
  const markSent = db.prepare('UPDATE orders SET materials_reminder_sent_at = ? WHERE id = ?');

  for (const order of candidates) {
    const message =
      `📦 Przypomnienie — zamówienie #${order.id} (${order.package_name}) wciąż czeka na materiały od <@${order.user_id}>. ` +
      `Minęło ${REMINDER_HOURS}h bez ruchu.`;

    if (order.ticket_channel_id) {
      try {
        const channel = await client.channels.fetch(order.ticket_channel_id);
        await channel.send(message);
      } catch (_) {
        // kanał mógł zniknąć — log niżej i tak poleci
      }
    }

    try {
      const user = await client.users.fetch(order.user_id);
      await user.send(
        `📦 Przypominam o zamówieniu #${order.id} (${order.package_name}) — czekam na materiały (link do Drive/YouTube). ` +
          'Wpadnij na ticket, jak będziesz gotowy/a.'
      );
    } catch (_) {
      // DM zablokowany — wiadomość w tickecie i tak poszła
    }

    markSent.run(now, order.id);

    await logEvent(client, order.guild_id, 'info', `Wysłano przypomnienie o materiałach dla zamówienia #${order.id}.`);
  }

  return candidates.length;
}

module.exports = { sendMaterialsReminders, REMINDER_HOURS };
