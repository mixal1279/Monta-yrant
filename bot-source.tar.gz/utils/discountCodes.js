// Bezpieczny system kodów rabatowych. Walidacja i zużycie są rozdzielone,
// ale samo zużycie jest atomowe, aby równoległe requesty nie mogły przekroczyć limitu.
const crypto = require('crypto');
const { getDb } = require('../database/db');

function generateDiscountCode({ guildId, userId = null, discountType, discountValue, maxUses = 1, expiresAt = null, source = null, prefix = 'EDZZI' }) {
  const db = getDb();
  const code = `${prefix}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
  db.prepare(`INSERT INTO discount_codes
    (code, guild_id, user_id, discount_type, discount_value, max_uses, active, source, expires_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?)`).run(
      code, guildId, userId, discountType, discountValue, maxUses, source, expiresAt, new Date().toISOString()
    );
  return code;
}

function validateDiscountCode(code, guildId, userId) {
  if (typeof code !== 'string' || code.trim().length < 3 || code.length > 100) {
    return { valid: false, reason: 'Nieprawidłowy kod rabatowy.' };
  }
  const db = getDb();
  const normalized = code.trim().toUpperCase();
  const row = db.prepare('SELECT * FROM discount_codes WHERE code = ? AND guild_id = ? AND active = 1').get(normalized, guildId);
  if (!row) return { valid: false, reason: 'Kod nie istnieje albo jest nieaktywny.' };
  if (row.user_id && row.user_id !== userId) return { valid: false, reason: 'Ten kod jest przypisany do innego użytkownika.' };
  if (row.uses_count >= row.max_uses) return { valid: false, reason: 'Kod został już wykorzystany.' };
  if (row.expires_at && new Date(row.expires_at) < new Date()) return { valid: false, reason: 'Kod wygasł.' };
  return { valid: true, discount: row };
}

function applyDiscount(total, discount) {
  if (discount.discount_type === 'percent') {
    const percent = Math.min(100, Math.max(0, Number(discount.discount_value)));
    return Math.max(0, Math.round(total * (1 - percent / 100)));
  }
  return Math.max(0, Math.round(total - Number(discount.discount_value)));
}

// Atomowe zużycie: UPDATE wykona się tylko, gdy kod nadal jest aktywny,
// nie wygasł i ma wolne użycia. Zwracamy true wyłącznie, gdy zmieniono 1 wiersz.
function consumeDiscountCode(code, guildId, userId = null) {
  const db = getDb();
  const normalized = String(code || '').trim().toUpperCase();
  const now = new Date().toISOString();
  const result = db.prepare(`UPDATE discount_codes
    SET uses_count = uses_count + 1,
        active = CASE WHEN uses_count + 1 >= max_uses THEN 0 ELSE active END
    WHERE code = ? AND guild_id = ? AND active = 1 AND uses_count < max_uses
      AND (expires_at IS NULL OR expires_at >= ?)
      AND (user_id IS NULL OR user_id = ?)`
  ).run(normalized, guildId, now, userId);
  return result.changes === 1;
}

function findExistingCodeFromSource(guildId, userId, source) {
  return getDb().prepare('SELECT * FROM discount_codes WHERE guild_id = ? AND user_id = ? AND source = ? ORDER BY id DESC LIMIT 1').get(guildId, userId, source);
}

module.exports = { generateDiscountCode, validateDiscountCode, applyDiscount, consumeDiscountCode, findExistingCodeFromSource };
