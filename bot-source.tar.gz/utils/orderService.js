const { getDb } = require('../database/db');
const { getConfig } = require('../config/config');

const LABELS = {
  pending_payment: 'Oczekuje na płatność',
  paid: 'Opłacone',
  in_progress: 'W trakcie realizacji',
  waiting_for_materials: 'Czeka na materiały',
  delivered: 'Dostarczone',
  completed: 'Zakończone',
  cancelled: 'Anulowane',
};

const ALLOWED = new Set(Object.keys(LABELS));

function getOrder(id) { return getDb().prepare('SELECT * FROM orders WHERE id = ?').get(Number(id)); }

async function notifyStatus(client, order, oldStatus, newStatus, actor = 'panel') {
  if (!client || !order || oldStatus === newStatus) return;
  const cfg = getConfig(order.guild_id);
  const channelId = cfg?.orders_notifications_channel_id || cfg?.orders_channel_id;
  const channel = channelId ? await client.channels.fetch(channelId).catch(() => null) : null;
  const text = `📦 **Zamówienie #${order.id}**: ${LABELS[oldStatus] || oldStatus} → **${LABELS[newStatus] || newStatus}**.`;
  if (channel) await channel.send({ content: text }).catch(() => {});
  getDb().prepare('INSERT INTO logs (guild_id, type, message, created_at) VALUES (?, ?, ?, ?)').run(order.guild_id, 'admin_audit', `status_change order=${order.id} actor=${actor} ${oldStatus}->${newStatus}`, new Date().toISOString());

  // DM jest opcjonalny i nie blokuje zmiany statusu.
  const user = await client.users.fetch(order.user_id).catch(() => null);
  if (user) await user.send(`📦 Zamówienie #${order.id}: status zmieniony na **${LABELS[newStatus] || newStatus}**.`).catch(() => {});
}

async function setOrderStatus(client, orderId, newStatus, actor = 'panel') {
  if (!ALLOWED.has(newStatus)) throw new Error('Nieprawidłowy status zamówienia.');
  const db = getDb();
  const order = getOrder(orderId);
  if (!order) throw new Error('Nie znaleziono zamówienia.');
  const now = new Date().toISOString();
  db.prepare('UPDATE orders SET status = ?, updated_at = ?, delivered_at = CASE WHEN ? = \'delivered\' THEN COALESCE(delivered_at, ?) ELSE delivered_at END WHERE id = ?')
    .run(newStatus, now, newStatus, now, order.id);
  const updated = getOrder(order.id);
  await notifyStatus(client, updated, order.status, newStatus, actor);
  return updated;
}

function listOrders({ guildId, status, search, limit = 50, offset = 0 }) {
  const db = getDb();
  const where = ['guild_id = ?']; const params = [guildId];
  if (status && ALLOWED.has(status)) { where.push('status = ?'); params.push(status); }
  if (search) { where.push('(CAST(id AS TEXT) LIKE ? OR user_id LIKE ? OR package_name LIKE ? OR game LIKE ?)'); const q = `%${search}%`; params.push(q,q,q,q); }
  const rows = db.prepare(`SELECT id,user_id,package_name,game,total_price,status,payment_method,created_at,updated_at,priority_deadline FROM orders WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ? OFFSET ?`).all(...params, Math.min(Number(limit)||50,100), Math.max(Number(offset)||0,0));
  const total = db.prepare(`SELECT COUNT(*) AS count FROM orders WHERE ${where.join(' AND ')}`).get(...params).count;
  return { rows, total };
}

function getOrderDetails(id, guildId) {
  return getDb().prepare('SELECT * FROM orders WHERE id = ? AND guild_id = ?').get(Number(id), guildId) || null;
}

module.exports = { LABELS, ALLOWED, getOrder, getOrderDetails, listOrders, setOrderStatus };
