// utils/pricing.js
// Cała logika liczenia cen — bazuje na danych z prices.json.

const prices = require('../prices.json');

function getPackage(key) {
  return prices.packages[key] || null;
}

function getBulkPackage(key) {
  return prices.bulk[key] || null;
}

function getAddon(key) {
  return prices.addons[key] || null;
}

function getSearchFeeTier(key) {
  return prices.searchFee[key] || null;
}

// Zwraca listę wszystkich opcji pakietów (pojedyncze + hurtowe) do select menu.
function getAllPackageOptions() {
  const single = Object.values(prices.packages).map((p) => ({
    value: p.key,
    label: `${p.name} — ${p.price} zł`,
    description: p.description.slice(0, 100),
    isBulk: false,
  }));
  const bulk = Object.values(prices.bulk).map((b) => ({
    value: b.key,
    label: `${b.name} — ${b.price} zł`,
    description: `Pakiet hurtowy: ${b.count} montaży w cenie pakietu`,
    isBulk: true,
  }));
  return [...single, ...bulk];
}

// Oblicza sumę zamówienia na podstawie sesji (patrz utils/sessionStore.js)
function calculateTotal(session) {
  let base = 0;
  let packageName = '';

  if (session.isBulk) {
    const bulk = getBulkPackage(session.packageKey);
    base = bulk.price;
    packageName = bulk.name;
  } else {
    const pkg = getPackage(session.packageKey);
    base = pkg.price;
    packageName = pkg.name;
  }

  const addonsPrice = (session.addons || []).reduce((sum, key) => {
    const addon = getAddon(key);
    return sum + (addon ? addon.price : 0);
  }, 0);

  const searchFee = session.searchFeeTier ? getSearchFeeTier(session.searchFeeTier).price : 0;

  const total = base + addonsPrice + searchFee;

  return { base, packageName, addonsPrice, searchFee, total };
}

module.exports = {
  prices,
  getPackage,
  getBulkPackage,
  getAddon,
  getSearchFeeTier,
  getAllPackageOptions,
  calculateTotal,
};
