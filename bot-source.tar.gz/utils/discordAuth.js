// utils/discordAuth.js
// Klient Discord OAuth2 (natywny fetch, Node 18+ — bez dodatkowych zależności).
// Używany wyłącznie do zalogowania klienta na stronie przed kręceniem kołem
// fortuny — scope 'identify' wystarcza, bo potrzebujemy tylko Discord ID,
// żeby przypiąć wygenerowany kod rabatowy do konkretnej osoby (anty-farming).
// Nie zapisujemy nigdzie access/refresh tokenu po zakończeniu żądania.

const SCOPE = 'identify';

function isDiscordOAuthConfigured() {
  // CLIENT_ID to to samo, co Application ID bota — Discord używa jednego ID
  // dla bota i dla OAuth2, nie trzeba zakładać osobnej aplikacji.
  return !!(process.env.CLIENT_ID && process.env.DISCORD_CLIENT_SECRET);
}

function redirectUri() {
  // Świadomie INNY adres niż PUBLIC_BASE_URL (używany przez Mollie/Google) —
  // logowanie Discord musi przechodzić przez Cloudflare Worker (HTTPS,
  // ta sama domena co /api/spin), inaczej cookie sesji wyląduje na domenie,
  // której przeglądarka nigdy nie odpyta przy kręceniu kołem. Patrz worker-spin-proxy.js.
  const base = process.env.DISCORD_OAUTH_PUBLIC_URL || process.env.PUBLIC_BASE_URL || `http://localhost:${process.env.WEBHOOK_PORT || 3000}`;
  return `${base}/oauth/discord/callback`;
}

function buildAuthUrl(state) {
  if (!isDiscordOAuthConfigured()) {
    throw new Error('Discord OAuth nie jest skonfigurowany (brak CLIENT_ID/DISCORD_CLIENT_SECRET w .env).');
  }
  const params = new URLSearchParams({
    client_id: process.env.CLIENT_ID,
    redirect_uri: redirectUri(),
    response_type: 'code',
    scope: SCOPE,
    state,
    // UWAGA: celowo BEZ prompt='none' — ten parametr każe Discordowi pominąć
    // ekran zgody, ale jeśli klient nigdy wcześniej nie autoryzował tej appki,
    // Discord zwróci błąd zamiast pokazać zgodę. Domyślne zachowanie (pokaż
    // zgodę, chyba że już autoryzowano) jest tu poprawne.
  });
  return `https://discord.com/api/oauth2/authorize?${params.toString()}`;
}

// Wymienia kod autoryzacji na access token, po czym pobiera podstawowe dane
// usera (id, username, avatar). Token jest używany tylko w tym jednym żądaniu.
async function exchangeCodeForUser(code) {
  if (!isDiscordOAuthConfigured()) {
    throw new Error('Discord OAuth nie jest skonfigurowany.');
  }

  const tokenRes = await fetch('https://discord.com/api/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: process.env.CLIENT_ID,
      client_secret: process.env.DISCORD_CLIENT_SECRET,
      grant_type: 'authorization_code',
      code,
      redirect_uri: redirectUri(),
    }),
  });

  if (!tokenRes.ok) {
    const errText = await tokenRes.text().catch(() => '');
    throw new Error(`Wymiana kodu na token nie powiodła się (${tokenRes.status}): ${errText}`);
  }

  const tokenData = await tokenRes.json();

  const userRes = await fetch('https://discord.com/api/users/@me', {
    headers: { Authorization: `${tokenData.token_type} ${tokenData.access_token}` },
  });

  if (!userRes.ok) {
    const errText = await userRes.text().catch(() => '');
    throw new Error(`Pobranie danych usera nie powiodło się (${userRes.status}): ${errText}`);
  }

  const user = await userRes.json();
  return {
    id: user.id,
    username: user.username,
    avatar: user.avatar,
  };
}

module.exports = { isDiscordOAuthConfigured, buildAuthUrl, exchangeCodeForUser };
