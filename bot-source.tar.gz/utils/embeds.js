// utils/embeds.js
// Wspólne embedy używane przez komendy i handlery — żeby nie duplikować stylu w kodzie.

const { EmbedBuilder } = require('discord.js');
const prices = require('../prices.json');
const { getAddon, getSearchFeeTier } = require('./pricing');

const BRAND_COLOR = 0xff6b00;

const REGULAMIN_TEXT = [
  '**Regulamin zamówień**',
  '',
  '1. Brak zwrotów po rozpoczęciu pracy nad zamówieniem.',
  '2. Liczba poprawek zależy od wybranego pakietu.',
  '3. Czas realizacji liczony jest od momentu zaksięgowania płatności **i** dostarczenia materiałów.',
  '4. Klient musi posiadać prawa do dostarczonych materiałów.',
  '5. Materiały dostarczane są wyłącznie przez Google Drive (lub link YouTube przy gotowych klipach).',
  '6. Zlecenie wyszukiwania momentów ze streama wydłuża czas realizacji.',
].join('\n');

function regulaminEmbed() {
  return new EmbedBuilder().setColor(BRAND_COLOR).setTitle('📜 Regulamin').setDescription(REGULAMIN_TEXT);
}

function cennikEmbed(stats = null) {
  const embed = new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle('🎬 Cennik — Montaż shortów gamingowych')
    .setDescription('Wybierz pakiet i kliknij **Zamów**, aby rozpocząć zamówienie.');

  const pkgLines = Object.values(prices.packages).map(
    (p) => `**${p.name} — ${p.price} zł**\n${p.description}`
  );
  embed.addFields({ name: '📦 Pakiety', value: pkgLines.join('\n\n') });

  const bulkLines = Object.values(prices.bulk).map((b) => `**${b.name} — ${b.price} zł**`);
  embed.addFields({ name: '📦 Pakiety hurtowe', value: bulkLines.join('\n') });

  const addonLines = Object.values(prices.addons).map((a) => `**${a.name}** — +${a.price} zł`);
  embed.addFields({ name: '➕ Dodatki', value: addonLines.join('\n') });

  const searchLines = Object.values(prices.searchFee).map((s) => `${s.label} — +${s.price} zł`);
  embed.addFields({
    name: '🔍 Wyszukiwanie momentów ze streama (jeśli brak gotowych klipów)',
    value: searchLines.join('\n'),
  });

  if (stats) {
    embed.addFields({
      name: '⭐ Statystyki',
      value: `Średnia ocena: **${stats.avgRating}/5** (${stats.reviewCount} opinii)`,
    });
  }

  embed.setFooter({ text: 'Kliknij przycisk poniżej, aby złożyć zamówienie' });
  return embed;
}

function orderSummaryEmbed(session, calc, discountInfo = {}) {
  const addonsText =
    (session.addons || []).length > 0
      ? session.addons.map((k) => getAddon(k).name).join(', ')
      : 'brak';

  const materialsText =
    session.materialsType === 'gotowe'
      ? 'Klient dostarcza gotowe klipy'
      : `Szukanie momentów ze streama (${getSearchFeeTier(session.searchFeeTier)?.label || '—'})`;

  const { discountAmount = 0, finalTotal = calc.total, discountCode = null } = discountInfo;

  const fields = [
    { name: 'Pakiet', value: calc.packageName, inline: true },
    { name: 'Gra', value: session.game || '—', inline: true },
    { name: 'Cena bazowa', value: `${calc.base} zł`, inline: true },
    { name: 'Dodatki', value: addonsText, inline: false },
    { name: 'Materiały', value: materialsText, inline: false },
    { name: 'Link do materiałów', value: session.materialsLink || '—', inline: false },
    { name: 'Timestampy', value: session.hasTimestamps === 'tak' ? 'Tak' : 'Nie', inline: true },
    { name: 'Uwagi', value: session.notes || 'brak', inline: false },
  ];

  if (discountCode && discountAmount > 0) {
    fields.push(
      { name: 'Cena przed rabatem', value: `${calc.total} zł`, inline: true },
      { name: `🎁 Rabat (${discountCode})`, value: `-${discountAmount} zł`, inline: true },
      { name: '💰 Łączna cena', value: `**${finalTotal} zł**`, inline: false }
    );
  } else {
    fields.push({ name: '💰 Łączna cena', value: `**${finalTotal} zł**`, inline: false });
  }

  return new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle('🧾 Podsumowanie zamówienia')
    .addFields(fields)
    .setFooter({ text: 'Zaakceptuj regulamin, aby utworzyć zamówienie' });
}

function orderTicketEmbed(order) {
  const addons = JSON.parse(order.addons || '[]');
  const addonsText = addons.length > 0 ? addons.map((k) => getAddon(k)?.name || k).join(', ') : 'brak';

  return new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle(`📋 Zamówienie #${order.id}`)
    .addFields(
      { name: 'Klient', value: `<@${order.user_id}>`, inline: true },
      { name: 'Status', value: statusLabel(order.status), inline: true },
      { name: 'Pakiet', value: order.package_name, inline: true },
      { name: 'Gra', value: order.game || '—', inline: true },
      { name: 'Cena', value: `${order.total_price} zł`, inline: true },
      { name: 'Dodatki', value: addonsText, inline: false },
      { name: 'Materiały', value: order.materials_link || '—', inline: false },
      { name: 'Timestampy', value: order.has_timestamps === 'tak' ? 'Tak' : 'Nie', inline: true },
      { name: 'Uwagi', value: order.notes || 'brak', inline: false }
    )
    .setTimestamp(new Date(order.created_at));
}

const STATUS_LABELS = {
  pending_payment: '🟡 Oczekuje na płatność',
  paid: '🟢 Opłacone',
  in_progress: '🔧 W trakcie realizacji',
  waiting_for_materials: '⏳ Czeka na materiały',
  delivered: '📦 Dostarczone',
  completed: '✅ Zakończone',
  cancelled: '❌ Anulowane',
};

function statusLabel(status) {
  return STATUS_LABELS[status] || status;
}

module.exports = {
  BRAND_COLOR,
  regulaminEmbed,
  cennikEmbed,
  orderSummaryEmbed,
  orderTicketEmbed,
  statusLabel,
  STATUS_LABELS,
};
