// utils/discordSessionStore.js
// Sesja logowania klienta na stronie po zalogowaniu przez Discord OAuth.
// Wzorowane na sessionStore.js (flow zamówień) — trzymane w pamięci procesu,
// bo to krótkotrwałe dane (wystarczy na czas jednej wizyty na stronie z kołem
// fortuny), nie trzeba tego przeżywać restartu bota ani osobnej tabeli w bazie.
//
// Klucz sesji to losowy token wysyłany do przeglądarki jako httpOnly cookie —
// klient nigdy nie widzi ani nie może podrobić Discord ID, bo token->userId
// żyje wyłącznie po stronie serwera.

const crypto = require('crypto');

const sessions = new Map(); // token -> { discordId, username, avatar, createdAt }
const SESSION_TTL_MS = 30 * 60 * 1000; // 30 minut wystarczy na zalogowanie się i zakręcenie kołem

function _cleanupExpired() {
  const now = Date.now();
  for (const [token, session] of sessions.entries()) {
    if (now - session.createdAt > SESSION_TTL_MS) sessions.delete(token);
  }
}

function createSession(discordUser) {
  _cleanupExpired();
  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, {
    discordId: discordUser.id,
    username: discordUser.username,
    avatar: discordUser.avatar,
    createdAt: Date.now(),
  });
  return token;
}

function getSession(token) {
  if (!token) return null;
  const session = sessions.get(token);
  if (!session) return null;
  if (Date.now() - session.createdAt > SESSION_TTL_MS) {
    sessions.delete(token);
    return null;
  }
  return session;
}

function clearSession(token) {
  sessions.delete(token);
}

module.exports = { createSession, getSession, clearSession, SESSION_TTL_MS };
