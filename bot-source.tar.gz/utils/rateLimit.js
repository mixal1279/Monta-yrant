// Prosty in-memory rate limiter. Dla pojedynczego procesu Node/Express.
// Przy wielu instancjach należy zastąpić go limiterem współdzielonym (np. Redis).
const buckets = new Map();

function rateLimit({ windowMs = 60_000, max = 60, keyGenerator = (req) => req.ip || 'unknown' } = {}) {
  return (req, res, next) => {
    const now = Date.now();
    const key = `${keyGenerator(req)}:${req.baseUrl || ''}${req.path || ''}`;
    let bucket = buckets.get(key);
    if (!bucket || now - bucket.startedAt >= windowMs) {
      bucket = { startedAt: now, count: 0 };
      buckets.set(key, bucket);
    }
    bucket.count += 1;
    res.setHeader('X-RateLimit-Limit', String(max));
    res.setHeader('X-RateLimit-Remaining', String(Math.max(0, max - bucket.count)));
    if (bucket.count > max) {
      const retryAfter = Math.ceil((bucket.startedAt + windowMs - now) / 1000);
      res.setHeader('Retry-After', String(Math.max(1, retryAfter)));
      return res.status(429).json({ error: 'rate_limited', message: 'Zbyt wiele żądań. Spróbuj ponownie za chwilę.' });
    }
    next();
  };
}

function cleanupRateLimitBuckets() {
  const cutoff = Date.now() - 10 * 60_000;
  for (const [key, bucket] of buckets) {
    if (bucket.startedAt < cutoff) buckets.delete(key);
  }
}
setInterval(cleanupRateLimitBuckets, 5 * 60_000).unref();

module.exports = { rateLimit };
