// utils/orderCleanup.js
// Zamówienia, które utknęły w stanie pending_payment (klient nie dokończył
// płatności i nic nie kliknął) są po określonym czasie automatycznie anulowane,
// żeby nie zaśmiecały statystyk/raportów i nie wisiały bez końca.

const { getDb } = require('../database/db');
const { logEvent } = require('./logger');

const STALE_HOURS = Number(process.env.STALE_ORDER_HOURS) || 24;

async function cancelStaleOrders(client) {
  const db = getDb();
  const cutoff = new Date(Date.now() - STALE_HOURS * 60 * 60 * 1000).toISOString();

  const stale = db
    .prepare(`SELECT * FROM orders WHERE status = 'pending_payment' AND created_at < ?`)
    .all(cutoff);

  if (stale.length === 0) return 0;

  const now = new Date().toISOString();
  const update = db.prepare(
    `UPDATE orders SET status = 'cancelled', cancel_reason = ?, updated_at = ? WHERE id = ?`
  );

  for (const order of stale) {
    update.run(`Automatyczne anulowanie — brak płatności przez ${STALE_HOURS}h`, now, order.id);

    await logEvent(
      client,
      order.guild_id,
      'anulowanie',
      `Zamówienie #${order.id} automatycznie anulowane — brak płatności przez ${STALE_HOURS}h.`
    );

    try {
      const user = await client.users.fetch(order.user_id);
      await user.send(
        `Twoje zamówienie #${order.id} (${order.package_name}, ${order.total_price} zł) zostało anulowane — ` +
          `minęło ${STALE_HOURS}h bez płatności. Możesz złożyć je ponownie poleceniem \`/zamowienie\`.`
      );
    } catch (_) {
      // DM zablokowany — trudno, informacja i tak została zalogowana
    }
  }

  return stale.length;
}

module.exports = { cancelStaleOrders, STALE_HOURS };
