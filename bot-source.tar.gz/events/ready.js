// events/ready.js
const { Events, ActivityType } = require('discord.js');
const { createBackup } = require('../utils/backupManager');
const { startHttpServer } = require('../server/httpServer');
const { cancelStaleOrders, STALE_HOURS } = require('../utils/orderCleanup');
const { checkPriorityDeadlines } = require('../utils/priorityTracking');
const { sendMaterialsReminders, REMINDER_HOURS } = require('../utils/materialsReminder');

const DAY_MS = 24 * 60 * 60 * 1000;
const HOUR_MS = 60 * 60 * 1000;
const QUARTER_HOUR_MS = 15 * 60 * 1000;
const SIX_HOURS_MS = 6 * 60 * 60 * 1000;

function runStaleOrderCleanup(client) {
  cancelStaleOrders(client)
    .then((n) => {
      if (n > 0) console.log(`🕒 Auto-anulowano ${n} zamówień bez płatności (>${STALE_HOURS}h).`);
    })
    .catch((err) => console.error('Błąd auto-anulowania zamówień:', err.message));
}

function runPriorityCheck(client) {
  checkPriorityDeadlines(client).catch((err) => console.error('Błąd sprawdzania deadline\'ów priorytetu:', err.message));
}

function runMaterialsReminders(client) {
  sendMaterialsReminders(client)
    .then((n) => {
      if (n > 0) console.log(`📦 Wysłano ${n} przypomnień o materiałach (>${REMINDER_HOURS}h bez ruchu).`);
    })
    .catch((err) => console.error('Błąd wysyłania przypomnień o materiałach:', err.message));
}

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    console.log(`✅ Zalogowano jako ${client.user.tag}`);
    client.user.setActivity('/zamowienie', { type: ActivityType.Watching });

    startHttpServer(client);

    // Automatyczny backup raz dziennie (pierwszy od razu po starcie, potem co 24h)
    try {
      const filename = createBackup();
      console.log(`🗄️ Backup startowy utworzony: ${filename}`);
    } catch (err) {
      console.error('Błąd backupu startowego:', err.message);
    }

    setInterval(() => {
      try {
        const filename = createBackup();
        console.log(`🗄️ Backup automatyczny utworzony: ${filename}`);
      } catch (err) {
        console.error('Błąd automatycznego backupu:', err.message);
      }
    }, DAY_MS);

    // Auto-anulowanie nieopłaconych zamówień — sprawdzenie od razu po starcie,
    // potem co godzinę (próg czasu: STALE_HOURS, domyślnie 24h).
    runStaleOrderCleanup(client);
    setInterval(() => runStaleOrderCleanup(client), HOUR_MS);

    // Deadline'y priorytetu — sprawdzane częściej (co 15 min), bo to tylko 12h okno.
    runPriorityCheck(client);
    setInterval(() => runPriorityCheck(client), QUARTER_HOUR_MS);

    // Przypominajki o brakujących materiałach — co 6h wystarczy, próg to REMINDER_HOURS.
    runMaterialsReminders(client);
    setInterval(() => runMaterialsReminders(client), SIX_HOURS_MS);
  },
};
