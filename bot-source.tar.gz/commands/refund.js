// commands/refund.js
// Zwrot płatności za zamówienie — użyj w kanale ticketu (zamówienie rozpoznawane
// po kanale) albo podaj order_id wprost.
//
// Dla CashBill przy działalności nierejestrowanej zwrot wykonuje się ręcznie
// w panelu CashBill, a ta komenda oznacza go w bazie.
//
// Brak setDefaultMemberPermissions celowo — widoczność jak przy przyciskach
// statusu w tickecie, dostęp weryfikowany wewnętrznie przez isStaffMember().

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getDb } = require('../database/db');
const { logEvent } = require('../utils/logger');
const { getConfig } = require('../config/config');
const { isStaffMember } = require('../utils/permissions');
const { BRAND_COLOR, statusLabel } = require('../utils/embeds');

function findOrder(interaction, explicitId) {
  const db = getDb();
  if (explicitId) return db.prepare('SELECT * FROM orders WHERE id = ?').get(explicitId);
  return db.prepare('SELECT * FROM orders WHERE ticket_channel_id = ?').get(interaction.channelId);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('refund')
    .setDescription('Zwróć płatność za zamówienie (staff)')
    .addIntegerOption((o) => o.setName('order_id').setDescription('ID zamówienia (jeśli nie jesteś w jego tickecie)'))
    .addStringOption((o) => o.setName('powod').setDescription('Powód zwrotu (opcjonalnie)')),

  async execute(interaction) {
    const cfg = getConfig(interaction.guildId);
    if (!isStaffMember(interaction.member, cfg)) {
      return interaction.reply({ content: 'Tylko staff może zlecać zwroty.', ephemeral: true });
    }

    const orderId = interaction.options.getInteger('order_id');
    const reason = interaction.options.getString('powod');
    const order = findOrder(interaction, orderId);

    if (!order) {
      return interaction.reply({
        content: 'Nie znaleziono zamówienia — użyj komendy w kanale ticketu albo podaj `order_id`.',
        ephemeral: true,
      });
    }

    if (order.refunded) {
      return interaction.reply({ content: `Zamówienie #${order.id} ma już oznaczony zwrot.`, ephemeral: true });
    }

    if (!['paid', 'in_progress', 'waiting_for_materials', 'delivered', 'completed'].includes(order.status)) {
      return interaction.reply({
        content: `Zamówienie #${order.id} ma status **${statusLabel(order.status)}** — nie ma jeszcze opłaconej kwoty do zwrotu.`,
        ephemeral: true,
      });
    }

    await interaction.deferReply();

    const db = getDb();
    const now = new Date().toISOString();

    db.prepare(
      `UPDATE orders SET status = 'cancelled', refunded = 1, cancel_reason = ?, updated_at = ? WHERE id = ?`
    ).run(
      reason || 'Zwrot ręczny w panelu operatora płatności',
      now,
      order.id
    );

    const embed = new EmbedBuilder().setColor(BRAND_COLOR).setTitle(`↩️ Zwrot — zamówienie #${order.id}`);

    embed.setDescription(
      `Zamówienie oznaczone jako zwrócone. **Wykonaj ręcznie zwrot ${order.total_price} zł w panelu operatora płatności** (CashBill) lub przelewem na konto klienta.`
    );

    if (reason) embed.addFields({ name: 'Powód', value: reason });

    await interaction.editReply({ embeds: [embed] });

    await logEvent(
      interaction.client,
      interaction.guildId,
      'anulowanie',
      `Zwrot dla zamówienia #${order.id} (przez <@${interaction.user.id}>)${reason ? ` — powód: ${reason}` : ''} — wymaga ręcznej obsługi w panelu operatora.`
    );
  },
};
