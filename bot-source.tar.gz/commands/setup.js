// commands/setup.js
// Konfiguracja serwera — ustawia kanały i role wykorzystywane przez bota.
// Tylko dla administratorów (uprawnienie Administrator wymagane do użycia komendy).

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } = require('discord.js');
const { setConfig, getConfig } = require('../config/config');
const { BRAND_COLOR } = require('../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Konfiguracja kanałów i ról bota (tylko admin)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addChannelOption((o) =>
      o.setName('orders_channel').setDescription('Kanał zamówień').addChannelTypes(ChannelType.GuildText)
    )
    .addChannelOption((o) =>
      o.setName('logs_channel').setDescription('Kanał logów').addChannelTypes(ChannelType.GuildText)
    )
    .addChannelOption((o) =>
      o.setName('portfolio_channel').setDescription('Kanał portfolio').addChannelTypes(ChannelType.GuildText)
    )
    .addChannelOption((o) =>
      o.setName('pricing_channel').setDescription('Kanał cennika').addChannelTypes(ChannelType.GuildText)
    )
    .addChannelOption((o) =>
      o
        .setName('ticket_category')
        .setDescription('Kategoria, w której tworzone są tickety')
        .addChannelTypes(ChannelType.GuildCategory)
    )
    .addRoleOption((o) => o.setName('admin_role').setDescription('Rola administratorów bota'))
    .addRoleOption((o) => o.setName('staff_role').setDescription('Rola staffu (montażystów)'))
    .addChannelOption((o) =>
      o
        .setName('orders_notifications_channel')
        .setDescription('Kanał powiadomień o nowych zamówieniach')
        .addChannelTypes(ChannelType.GuildText)
    )
    .addChannelOption((o) =>
      o.setName('reviews_channel').setDescription('Kanał opinii').addChannelTypes(ChannelType.GuildText)
    ),

  async execute(interaction) {
    const updates = {};
    const map = {
      orders_channel: 'orders_channel_id',
      logs_channel: 'logs_channel_id',
      portfolio_channel: 'portfolio_channel_id',
      pricing_channel: 'pricing_channel_id',
      ticket_category: 'ticket_category_id',
      admin_role: 'admin_role_id',
      staff_role: 'staff_role_id',
      orders_notifications_channel: 'orders_notifications_channel_id',
      reviews_channel: 'reviews_channel_id',
    };

    let anyProvided = false;
    for (const [optionName, field] of Object.entries(map)) {
      const value = interaction.options.get(optionName)?.value;
      if (value) {
        updates[field] = value;
        anyProvided = true;
      }
    }

    if (!anyProvided) {
      const cfg = getConfig(interaction.guildId);
      return interaction.reply({ embeds: [buildConfigEmbed(cfg)], ephemeral: true });
    }

    const cfg = setConfig(interaction.guildId, updates);
    await interaction.reply({
      content: '✅ Konfiguracja zaktualizowana.',
      embeds: [buildConfigEmbed(cfg)],
      ephemeral: true,
    });
  },
};

function buildConfigEmbed(cfg) {
  const fmt = (id, type) => (id ? (type === 'role' ? `<@&${id}>` : `<#${id}>`) : '— nie ustawiono —');
  return new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle('⚙️ Aktualna konfiguracja')
    .addFields(
      { name: 'Kanał zamówień', value: fmt(cfg?.orders_channel_id), inline: true },
      { name: 'Kanał logów', value: fmt(cfg?.logs_channel_id), inline: true },
      { name: 'Kanał portfolio', value: fmt(cfg?.portfolio_channel_id), inline: true },
      { name: 'Kanał cennika', value: fmt(cfg?.pricing_channel_id), inline: true },
      { name: 'Kategoria ticketów', value: fmt(cfg?.ticket_category_id), inline: true },
      { name: 'Rola admina', value: fmt(cfg?.admin_role_id, 'role'), inline: true },
      { name: 'Rola staffu', value: fmt(cfg?.staff_role_id, 'role'), inline: true },
      { name: 'Powiadomienia o zamówieniach', value: fmt(cfg?.orders_notifications_channel_id), inline: true },
      { name: 'Kanał opinii', value: fmt(cfg?.reviews_channel_id), inline: true }
    );
}
