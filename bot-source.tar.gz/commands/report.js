// commands/report.js
// Generuje raport miesięczny: liczba zamówień, przychód, średnia ocena, top pakiet, top gra.

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { monthlyReport } = require('../utils/exportData');
const { BRAND_COLOR } = require('../utils/embeds');

const MONTHS_PL = [
  'styczeń', 'luty', 'marzec', 'kwiecień', 'maj', 'czerwiec',
  'lipiec', 'sierpień', 'wrzesień', 'październik', 'listopad', 'grudzień',
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('report')
    .setDescription('Raporty (tylko admin)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub
        .setName('monthly')
        .setDescription('Raport miesięczny')
        .addIntegerOption((o) => o.setName('miesiac').setDescription('Miesiąc (1-12)').setMinValue(1).setMaxValue(12))
        .addIntegerOption((o) => o.setName('rok').setDescription('Rok (np. 2026)'))
    ),

  async execute(interaction) {
    const now = new Date();
    const month = interaction.options.getInteger('miesiac') || now.getMonth() + 1;
    const year = interaction.options.getInteger('rok') || now.getFullYear();

    const report = monthlyReport(interaction.guildId, year, month);

    const embed = new EmbedBuilder()
      .setColor(BRAND_COLOR)
      .setTitle(`📊 Raport — ${MONTHS_PL[month - 1]} ${year}`)
      .addFields(
        { name: 'Liczba zamówień', value: String(report.orderCount), inline: true },
        { name: 'Zakończone/dostarczone', value: String(report.completedCount), inline: true },
        { name: 'Przychód', value: `${report.revenue} zł`, inline: true },
        { name: 'Średnia ocena', value: report.avgRating ? `${report.avgRating}/5 (${report.reviewCount})` : 'brak opinii', inline: true },
        { name: 'Popularny pakiet', value: report.topPackage, inline: true },
        { name: 'Popularna gra', value: report.topGame, inline: true }
      );

    await interaction.reply({ embeds: [embed] });
  },
};
