// commands/kolejka.js
// Podgląd dla staffu: wszystkie zamówienia w trakcie realizacji (opłacone,
// w trakcie, czekające na materiały), od najstarszego do najnowszego —
// żeby łatwo zobaczyć, co czeka najdłużej i co ma priorytet.

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getDb } = require('../database/db');
const { getConfig } = require('../config/config');
const { isStaffMember } = require('../utils/permissions');
const { statusLabel, BRAND_COLOR } = require('../utils/embeds');

const ACTIVE_STATUSES = ['paid', 'in_progress', 'waiting_for_materials'];
const MAX_SHOWN = 15;

function hasPriorityAddon(order) {
  try {
    return JSON.parse(order.addons || '[]').includes('priority');
  } catch (_) {
    return false;
  }
}

module.exports = {
  data: new SlashCommandBuilder().setName('kolejka').setDescription('Podgląd aktywnych zamówień (staff)'),

  async execute(interaction) {
    const cfg = getConfig(interaction.guildId);
    if (!isStaffMember(interaction.member, cfg)) {
      return interaction.reply({ content: 'Ta komenda jest tylko dla staffu.', ephemeral: true });
    }

    const db = getDb();
    const placeholders = ACTIVE_STATUSES.map(() => '?').join(',');
    const orders = db
      .prepare(`SELECT * FROM orders WHERE guild_id = ? AND status IN (${placeholders}) ORDER BY created_at ASC`)
      .all(interaction.guildId, ...ACTIVE_STATUSES);

    if (orders.length === 0) {
      return interaction.reply({ content: '✅ Pusto — brak aktywnych zamówień w kolejce.', ephemeral: true });
    }

    const lines = orders.slice(0, MAX_SHOWN).map((o) => {
      const priority = hasPriorityAddon(o) ? ' 🔥PRIORYTET' : '';
      const ticketRef = o.ticket_channel_id ? ` — <#${o.ticket_channel_id}>` : '';
      return `**#${o.id}** ${statusLabel(o.status)}${priority} — ${o.package_name}, ${o.game || '—'} (<@${o.user_id}>)${ticketRef}`;
    });

    const embed = new EmbedBuilder()
      .setColor(BRAND_COLOR)
      .setTitle(`📋 Kolejka — ${orders.length} aktywnych zamówień`)
      .setDescription(lines.join('\n'));

    if (orders.length > MAX_SHOWN) {
      embed.setFooter({ text: `Pokazano ${MAX_SHOWN} z ${orders.length} — najstarsze pierwsze.` });
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
