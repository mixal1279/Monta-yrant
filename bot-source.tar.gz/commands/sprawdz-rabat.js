// commands/sprawdz-rabat.js
// Start weryfikacji: klient klika link, loguje się przez Google, zgadza się
// na odczyt swoich subskrypcji YouTube. Wynik (kod rabatowy albo odmowa)
// wraca do niego w DM po przejściu przez server/googleAuthRoutes.js.

const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { isGoogleConfigured, buildAuthUrl } = require('../utils/googleAuth');
const { createState } = require('../utils/oauthStateStore');
const { BRAND_COLOR } = require('../utils/embeds');

const MIN_DAYS = Number(process.env.EDZZI_SUB_MIN_DAYS) || 30;
const DISCOUNT_MIN = Number(process.env.EDZZI_SUB_DISCOUNT_MIN) || 5;
const DISCOUNT_MAX = Number(process.env.EDZZI_SUB_DISCOUNT_MAX) || 25;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sprawdz-rabat')
    .setDescription(`Sprawdź, czy masz losowy rabat (${DISCOUNT_MIN}-${DISCOUNT_MAX}%) za subskrypcję Edzzi_Minecraft`),

  async execute(interaction) {
    if (!isGoogleConfigured()) {
      return interaction.reply({
        content: 'Weryfikacja subskrypcji nie jest jeszcze skonfigurowana na tym serwerze.',
        ephemeral: true,
      });
    }

    const state = createState(interaction.user.id, interaction.guildId);
    const url = buildAuthUrl(state);

    const embed = new EmbedBuilder()
      .setColor(BRAND_COLOR)
      .setTitle('🎁 Rabat za subskrypcję')
      .setDescription(
        `Jeśli subskrybujesz kanał **Edzzi_Minecraft** na YouTube od minimum ${MIN_DAYS} dni, dostaniesz losowy kod rabatowy w przedziale **${DISCOUNT_MIN}-${DISCOUNT_MAX}%**.\n\n` +
          'Kliknij przycisk, zaloguj się na Google i zgódź się na odczyt swoich subskrypcji (tylko do sprawdzenia, nic nie zmieniamy ani nie zapisujemy Twojego konta). ' +
          'Wynik dostaniesz w wiadomości prywatnej na Discordzie.'
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel('Zweryfikuj przez Google').setStyle(ButtonStyle.Link).setURL(url)
    );

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  },
};
