// commands/backup.js
// Zarządzanie backupami bazy danych — create / list / restore / delete.
// Tylko dla administratorów.

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { createBackup, listBackups, restoreBackup, deleteBackup } = require('../utils/backupManager');
const { logEvent } = require('../utils/logger');
const { BRAND_COLOR } = require('../utils/embeds');

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('backup')
    .setDescription('Zarządzanie backupami bazy danych (tylko admin)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) => sub.setName('create').setDescription('Utwórz nowy backup'))
    .addSubcommand((sub) => sub.setName('list').setDescription('Lista dostępnych backupów'))
    .addSubcommand((sub) =>
      sub
        .setName('restore')
        .setDescription('Przywróć backup (nadpisuje bieżącą bazę!)')
        .addStringOption((o) => o.setName('plik').setDescription('Nazwa pliku backupu').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('delete')
        .setDescription('Usuń backup')
        .addStringOption((o) => o.setName('plik').setDescription('Nazwa pliku backupu').setRequired(true))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'create') {
      try {
        const filename = createBackup();
        await interaction.reply({ content: `✅ Backup utworzony: \`${filename}\`` });
        await logEvent(interaction.client, interaction.guildId, 'backup', `Utworzono backup: ${filename} (przez <@${interaction.user.id}>).`);
      } catch (err) {
        await interaction.reply({ content: `⚠️ Błąd backupu: ${err.message}`, ephemeral: true });
      }
      return;
    }

    if (sub === 'list') {
      const files = listBackups();
      if (files.length === 0) {
        return interaction.reply({ content: 'Brak zapisanych backupów.', ephemeral: true });
      }
      const embed = new EmbedBuilder()
        .setColor(BRAND_COLOR)
        .setTitle('🗄️ Dostępne backupy')
        .setDescription(
          files
            .map((f) => `\`${f.name}\` — ${formatSize(f.size)} — <t:${Math.floor(f.mtime / 1000)}:R>`)
            .join('\n')
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'restore') {
      const filename = interaction.options.getString('plik');
      try {
        restoreBackup(filename);
        await interaction.reply({ content: `✅ Przywrócono backup: \`${filename}\`. Baza danych została podmieniona.` });
        await logEvent(interaction.client, interaction.guildId, 'backup', `Przywrócono backup ${filename} (przez <@${interaction.user.id}>).`);
      } catch (err) {
        await interaction.reply({ content: `⚠️ Błąd przywracania: ${err.message}`, ephemeral: true });
      }
      return;
    }

    if (sub === 'delete') {
      const filename = interaction.options.getString('plik');
      try {
        deleteBackup(filename);
        await interaction.reply({ content: `✅ Usunięto backup: \`${filename}\`.`, ephemeral: true });
        await logEvent(interaction.client, interaction.guildId, 'backup', `Usunięto backup ${filename} (przez <@${interaction.user.id}>).`);
      } catch (err) {
        await interaction.reply({ content: `⚠️ Błąd usuwania: ${err.message}`, ephemeral: true });
      }
    }
  },
};
