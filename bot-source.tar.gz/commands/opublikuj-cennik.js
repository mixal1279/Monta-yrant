// commands/opublikuj-cennik.js
// Publikuje (lub odświeża, jeśli już istnieje) wiadomość z cennikiem na skonfigurowanym kanale.

const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getConfig, setConfig } = require('../config/config');
const { cennikEmbed } = require('../utils/embeds');
const { overallStats } = require('../utils/exportData');

function pricingButtonsRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('pricing_zamow').setLabel('Zamów').setStyle(ButtonStyle.Success).setEmoji('🛒'),
    new ButtonBuilder().setCustomId('pricing_regulamin').setLabel('Regulamin').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('pricing_opinie').setLabel('Opinie').setStyle(ButtonStyle.Secondary).setEmoji('⭐'),
    new ButtonBuilder().setCustomId('pricing_portfolio').setLabel('Portfolio').setStyle(ButtonStyle.Secondary).setEmoji('🎬')
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('opublikuj-cennik')
    .setDescription('Publikuje wiadomość z cennikiem na kanale cennika (tylko admin)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const cfg = getConfig(interaction.guildId);
    const channelId = cfg?.pricing_channel_id || interaction.channelId;
    const channel = await interaction.guild.channels.fetch(channelId).catch(() => null);

    if (!channel) {
      return interaction.reply({
        content: '⚠️ Nie znaleziono kanału cennika. Ustaw go najpierw przez `/setup`.',
        ephemeral: true,
      });
    }

    const stats = overallStats(interaction.guildId);
    const message = await channel.send({
      embeds: [cennikEmbed(stats)],
      components: [pricingButtonsRow()],
    });

    setConfig(interaction.guildId, {
      pricing_message_id: message.id,
      pricing_message_channel_id: channel.id,
    });

    await interaction.reply({ content: `✅ Cennik opublikowany na <#${channel.id}>.`, ephemeral: true });
  },

  pricingButtonsRow,
};
