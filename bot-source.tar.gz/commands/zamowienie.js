// commands/zamowienie.js
// Rozpoczyna wieloetapowy proces składania zamówienia (select menu z pakietami).
// Reszta kroków obsługiwana jest w handlers/orderFlow.js, bo odpowiada na
// interakcje (select/button/modal) wywołane z tej pierwszej wiadomości.

const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { getAllPackageOptions } = require('../utils/pricing');
const { startSession, hasActiveSession } = require('../utils/sessionStore');
const { getActiveOrderForUser } = require('../tickets/ticketManager');

// Wspólna logika startu zamówienia — używana zarówno przez komendę /zamowienie,
// jak i przycisk "Zamów" na wiadomości z cennikiem.
async function startOrderFlow(interaction) {
  const activeOrder = getActiveOrderForUser(interaction.guildId, interaction.user.id);
  if (activeOrder) {
    return interaction.reply({
      content: `Masz już aktywne zamówienie (#${activeOrder.id}) w toku — sprawdź <#${activeOrder.ticket_channel_id}>.`,
      ephemeral: true,
    });
  }

  if (hasActiveSession(interaction.user.id)) {
    return interaction.reply({
      content: 'Masz już rozpoczęty proces składania zamówienia. Dokończ go lub poczekaj na wygaśnięcie sesji (15 min).',
      ephemeral: true,
    });
  }

  startSession(interaction.user.id, interaction.guildId);

  const options = getAllPackageOptions();
  const menu = new StringSelectMenuBuilder()
    .setCustomId('order_package_select')
    .setPlaceholder('Wybierz pakiet')
    .addOptions(options.map((o) => ({ label: o.label, value: o.value, description: o.description })));

  const row = new ActionRowBuilder().addComponents(menu);

  await interaction.reply({
    content: '**Krok 1/5 — Wybierz pakiet:**',
    components: [row],
    ephemeral: true,
  });
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('zamowienie')
    .setDescription('Złóż zamówienie na montaż shorta gamingowego'),

  execute: startOrderFlow,
  startOrderFlow,
};
