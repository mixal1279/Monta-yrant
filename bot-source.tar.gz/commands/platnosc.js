// commands/platnosc.js
// /platnosc status — pokazuje status zamówienia do czasu podłączenia CashBill.

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getDb } = require('../database/db');
const { statusLabel, BRAND_COLOR } = require('../utils/embeds');
const { getConfig } = require('../config/config');
const { isStaffMember } = require('../utils/permissions');

function findOrder(interaction, explicitId) {
  const db = getDb();
  if (explicitId) return db.prepare('SELECT * FROM orders WHERE id = ?').get(explicitId);

  // W kanale ticketu -> zamówienie tego ticketu.
  const byChannel = db.prepare('SELECT * FROM orders WHERE ticket_channel_id = ?').get(interaction.channelId);
  if (byChannel) return byChannel;

  // Poza ticketem -> ostatnie zamówienie tego użytkownika na tym serwerze.
  return db
    .prepare('SELECT * FROM orders WHERE guild_id = ? AND user_id = ? ORDER BY id DESC LIMIT 1')
    .get(interaction.guildId, interaction.user.id);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('platnosc')
    .setDescription('Sprawdź status płatności')
    .addSubcommand((sub) =>
      sub
        .setName('status')
        .setDescription('Sprawdź status płatności zamówienia')
        .addIntegerOption((o) =>
          o.setName('order_id').setDescription('ID zamówienia (domyślnie: bieżący ticket / Twoje ostatnie)')
        )
    ),

  async execute(interaction) {
    const orderId = interaction.options.getInteger('order_id');
    const order = findOrder(interaction, orderId);

    if (!order) {
      return interaction.reply({ content: 'Nie znaleziono zamówienia.', ephemeral: true });
    }

    const cfg = getConfig(interaction.guildId);
    const staff = isStaffMember(interaction.member, cfg);
    if (order.user_id !== interaction.user.id && !staff) {
      return interaction.reply({ content: 'To nie jest Twoje zamówienie.', ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: !staff });

    if (order.status !== 'pending_payment') {
      return interaction.editReply(
        `Zamówienie #${order.id} ma już status: **${statusLabel(order.status)}** — nie ma czego sprawdzać.`
      );
    }

    return interaction.editReply(
      `Zamówienie #${order.id} ma status **${statusLabel(order.status)}**. Automatyczna weryfikacja CashBill zostanie aktywowana po konfiguracji Punktu Płatności.`
    );
  },
};
