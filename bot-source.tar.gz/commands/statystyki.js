// commands/statystyki.js
// Ogólne statystyki — dostępne dla każdego (nie tylko admina), żeby klienci
// też mogli zobaczyć np. średnią ocenę.

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { overallStats } = require('../utils/exportData');
const { BRAND_COLOR } = require('../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('statystyki').setDescription('Pokazuje ogólne statystyki zamówień'),

  async execute(interaction) {
    const stats = overallStats(interaction.guildId);

    const embed = new EmbedBuilder()
      .setColor(BRAND_COLOR)
      .setTitle('📈 Statystyki')
      .addFields(
        { name: 'Liczba zamówień', value: String(stats.orderCount), inline: true },
        { name: 'Przychód', value: `${stats.revenue} zł`, inline: true },
        { name: 'Średnia ocena', value: stats.avgRating ? `${stats.avgRating}/5 (${stats.reviewCount})` : 'brak opinii', inline: true },
        { name: 'Najpopularniejszy pakiet', value: stats.topPackage, inline: true },
        { name: 'Najpopularniejsza gra', value: stats.topGame, inline: true }
      );

    await interaction.reply({ embeds: [embed] });
  },
};
