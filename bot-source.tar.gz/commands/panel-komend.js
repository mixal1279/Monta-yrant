// commands/panel-komend.js
// Wysyła embed z listą wszystkich komend bota na wskazany kanał.

const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');
const { BRAND_COLOR } = require('../utils/embeds');
const { isStaffMember } = require('../utils/permissions');
const { getConfig } = require('../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('panel-komend')
    .setDescription('Wysyła panel z listą komend bota na wybrany kanał (tylko admin)')
    .addChannelOption((o) =>
      o
        .setName('kanal')
        .setDescription('Kanał na który wysłać panel')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    ),

  async execute(interaction) {
    const cfg = getConfig(interaction.guildId);
    const isStaff = isStaffMember(interaction.member, cfg);
    if (!isStaff) {
      return interaction.reply({ content: 'Tylko staff może używać tej komendy.', ephemeral: true });
    }

    const kanal = interaction.options.getChannel('kanal');

    const embedKlient = new EmbedBuilder()
      .setColor(BRAND_COLOR)
      .setTitle('🎬 Komendy dla klientów')
      .addFields(
        {
          name: '`/zamowienie`',
          value: 'Złóż zamówienie na montaż shorta gamingowego. Bot przeprowadzi Cię przez cały proces krok po kroku.',
        },
        {
          name: '`/moje-zamowienia`',
          value: 'Sprawdź historię swoich zamówień — statusy, daty, pakiety.',
        },
        {
          name: '`/platnosc status`',
          value: 'Sprawdź aktualny status płatności Mollie dla swojego zamówienia.',
        },
        {
          name: '`/sprawdz-rabat`',
          value: 'Sprawdź czy przysługuje Ci losowy rabat za subskrypcję Edzzi_Minecraft.',
        }
      );

    const embedStaff = new EmbedBuilder()
      .setColor(BRAND_COLOR)
      .setTitle('🔧 Komendy dla staffu')
      .addFields(
        {
          name: '`/kolejka`',
          value: 'Podgląd wszystkich aktywnych zamówień — kto czeka, jaki status, priorytety.',
        },
        {
          name: '`/refund`',
          value: 'Zwróć płatność za zamówienie. Możesz podać ID zamówienia i opcjonalny powód zwrotu.',
        },
        {
          name: '`/statystyki`',
          value: 'Ogólne statystyki zamówień — liczba, przychód, średnia ocena.',
        }
      );

    const embedAdmin = new EmbedBuilder()
      .setColor(BRAND_COLOR)
      .setTitle('⚙️ Komendy dla adminów')
      .addFields(
        {
          name: '`/setup`',
          value: 'Konfiguracja kanałów i ról bota — kanał zamówień, logów, portfolio, kategoria ticketów, role staff/admin.',
        },
        {
          name: '`/opublikuj-cennik`',
          value: 'Publikuje wiadomość z cennikiem na kanale cennika.',
        },
        {
          name: '`/aktualizuj-cennik`',
          value: 'Odświeża wcześniej opublikowaną wiadomość z cennikiem.',
        },
        {
          name: '`/report monthly`',
          value: 'Raport miesięczny — liczba zamówień, przychód, zakończone.',
        },
        {
          name: '`/export orders`',
          value: 'Eksport zamówień do pliku CSV lub XLSX.',
        },
        {
          name: '`/backup create` / `list`',
          value: 'Tworzenie i przeglądanie backupów bazy danych.',
        },
        {
          name: '`/panel-komend`',
          value: 'Wysyła ten panel na wybrany kanał.',
        }
      )
      .setFooter({ text: 'MontaŻyrant Bot • Wszystkie komendy są slash commandami (/)' });

    await kanal.send({ embeds: [embedKlient, embedStaff, embedAdmin] });

    await interaction.reply({
      content: `✅ Panel komend został wysłany na <#${kanal.id}>`,
      ephemeral: true,
    });
  },
};
