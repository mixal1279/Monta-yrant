// commands/export.js
// Eksportuje zamówienia lub opinie do pliku CSV/XLSX i wysyła jako załącznik.

const { SlashCommandBuilder, PermissionFlagsBits, AttachmentBuilder } = require('discord.js');
const { exportOrders, exportReviews } = require('../utils/exportData');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('export')
    .setDescription('Eksport danych do pliku (tylko admin)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub
        .setName('orders')
        .setDescription('Eksportuj zamówienia')
        .addStringOption((o) =>
          o
            .setName('format')
            .setDescription('Format pliku')
            .setRequired(true)
            .addChoices({ name: 'CSV', value: 'csv' })
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('reviews')
        .setDescription('Eksportuj opinie')
        .addStringOption((o) =>
          o
            .setName('format')
            .setDescription('Format pliku')
            .setRequired(true)
            .addChoices({ name: 'CSV', value: 'csv' })
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const format = interaction.options.getString('format');

    await interaction.deferReply({ ephemeral: true });

    try {
      const filePath =
        sub === 'orders'
          ? await exportOrders(interaction.guildId, format)
          : await exportReviews(interaction.guildId, format);

      const attachment = new AttachmentBuilder(filePath);
      await interaction.editReply({ content: `✅ Eksport gotowy (${sub}, ${format}).`, files: [attachment] });
    } catch (err) {
      console.error(err);
      await interaction.editReply({ content: `⚠️ Błąd eksportu: ${err.message}` });
    }
  },
};
