// commands/moje-zamowienia.js
// Klient widzi historię swoich zamówień bez potrzeby grzebania w (czasem
// już zamkniętych) kanałach ticketów.

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getDb } = require('../database/db');
const { statusLabel, BRAND_COLOR } = require('../utils/embeds');

const MAX_SHOWN = 10;

module.exports = {
  data: new SlashCommandBuilder().setName('moje-zamowienia').setDescription('Pokazuje Twoją historię zamówień'),

  async execute(interaction) {
    const db = getDb();
    const orders = db
      .prepare('SELECT * FROM orders WHERE guild_id = ? AND user_id = ? ORDER BY id DESC LIMIT ?')
      .all(interaction.guildId, interaction.user.id, MAX_SHOWN);

    if (orders.length === 0) {
      return interaction.reply({
        content: 'Nie masz jeszcze żadnych zamówień — użyj `/zamowienie`, żeby złożyć pierwsze.',
        ephemeral: true,
      });
    }

    const lines = orders.map((o) => {
      const date = new Date(o.created_at).toLocaleDateString('pl-PL');
      const discount = o.discount_code ? ` (rabat ${o.discount_code}, -${o.discount_amount} zł)` : '';
      return `**#${o.id}** — ${o.package_name}, ${o.game || '—'} — **${o.total_price} zł**${discount}\n${statusLabel(
        o.status
      )} • ${date}`;
    });

    const embed = new EmbedBuilder()
      .setColor(BRAND_COLOR)
      .setTitle('🧾 Twoje zamówienia')
      .setDescription(lines.join('\n\n'));

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
