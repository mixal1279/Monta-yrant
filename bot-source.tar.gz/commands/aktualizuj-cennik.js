// commands/aktualizuj-cennik.js
// Edytuje wcześniej opublikowaną wiadomość z cennikiem (np. po zmianie prices.json).

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getConfig } = require('../config/config');
const { cennikEmbed } = require('../utils/embeds');
const { overallStats } = require('../utils/exportData');
const { pricingButtonsRow } = require('./opublikuj-cennik');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('aktualizuj-cennik')
    .setDescription('Odświeża wcześniej opublikowaną wiadomość z cennikiem (tylko admin)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const cfg = getConfig(interaction.guildId);
    if (!cfg?.pricing_message_id || !cfg?.pricing_message_channel_id) {
      return interaction.reply({
        content: '⚠️ Nie znaleziono opublikowanego cennika. Użyj najpierw `/opublikuj-cennik`.',
        ephemeral: true,
      });
    }

    const channel = await interaction.guild.channels.fetch(cfg.pricing_message_channel_id).catch(() => null);
    const message = channel ? await channel.messages.fetch(cfg.pricing_message_id).catch(() => null) : null;

    if (!message) {
      return interaction.reply({
        content: '⚠️ Wiadomość z cennikiem nie istnieje już na serwerze. Opublikuj ją ponownie przez `/opublikuj-cennik`.',
        ephemeral: true,
      });
    }

    const stats = overallStats(interaction.guildId);
    await message.edit({ embeds: [cennikEmbed(stats)], components: [pricingButtonsRow()] });

    await interaction.reply({ content: '✅ Cennik zaktualizowany.', ephemeral: true });
  },
};
