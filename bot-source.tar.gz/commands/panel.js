const { SlashCommandBuilder } = require('discord.js');
const SITE_URL = process.env.SITE_URL || '';
module.exports = {
  data: new SlashCommandBuilder().setName('panel').setDescription('Otwiera panel obsługi zamówień na stronie.'),
  async execute(interaction) {
    if (!SITE_URL) return interaction.reply({ content:'Panel nie ma ustawionego SITE_URL.', ephemeral:true });
    await interaction.reply({ content:`🖥️ Panel zamówień: ${SITE_URL}/panel.html`, ephemeral:true });
  }
};
