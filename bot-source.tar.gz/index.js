// index.js
// Punkt wejścia aplikacji. Ładuje komendy z /commands, eventy z /events,
// inicjalizuje bazę danych i loguje bota do Discorda.

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Collection, Partials } = require('discord.js');

// Inicjalizacja bazy danych przy starcie (tworzy plik + tabele, jeśli nie istnieją)
require('./database/db').getDb();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
  ],
  partials: [Partials.Channel],
});

// ---------- Ładowanie komend ----------
client.commands = new Collection();
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter((f) => ['setup.js', 'panel.js'].includes(f));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  if (command?.data?.name && typeof command.execute === 'function') {
    client.commands.set(command.data.name, command);
  } else {
    console.warn(`⚠️ Plik komendy ${file} nie eksportuje poprawnie { data, execute } — pominięto.`);
  }
}
console.log(`📦 Załadowano ${client.commands.size} komend.`);

// ---------- Ładowanie eventów ----------
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter((f) => f.endsWith('.js'));

for (const file of eventFiles) {
  const event = require(path.join(eventsPath, file));
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args));
  } else {
    client.on(event.name, (...args) => event.execute(...args));
  }
}
console.log(`📡 Załadowano ${eventFiles.length} eventów.`);

// ---------- Globalna obsługa nieoczekiwanych błędów — bot ma być odporny na restart ----------
process.on('unhandledRejection', (err) => {
  console.error('Nieobsłużone odrzucenie obietnicy:', err);
});
process.on('uncaughtException', (err) => {
  console.error('Nieobsłużony wyjątek:', err);
});

const token = process.env.DISCORD_TOKEN;
if (!token) {
  console.error('❌ Brak DISCORD_TOKEN w pliku .env — uzupełnij go i uruchom ponownie.');
  process.exit(1);
}

client.login(token);
