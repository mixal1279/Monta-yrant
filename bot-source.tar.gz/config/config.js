// config/config.js
// Pomocnik do odczytu i zapisu konfiguracji per-serwer (kanały, role, wiadomość cennika).
// Konfiguracja trzymana jest w SQLite (tabela config), jeden wiersz na guild_id.

const { getDb } = require('../database/db');

const FIELDS = [
  'orders_channel_id',
  'logs_channel_id',
  'portfolio_channel_id',
  'pricing_channel_id',
  'ticket_category_id',
  'admin_role_id',
  'staff_role_id',
  'orders_notifications_channel_id',
  'reviews_channel_id',
  'pricing_message_id',
  'pricing_message_channel_id',
];

function getConfig(guildId) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM config WHERE guild_id = ?').get(guildId);
  return row || null;
}

function ensureConfigRow(guildId) {
  const db = getDb();
  db.prepare('INSERT OR IGNORE INTO config (guild_id) VALUES (?)').run(guildId);
}

// updates: obiekt { pole: wartosc } — tylko pola z FIELDS są zapisywane
function setConfig(guildId, updates) {
  const db = getDb();
  ensureConfigRow(guildId);

  const keys = Object.keys(updates).filter((k) => FIELDS.includes(k));
  if (keys.length === 0) return getConfig(guildId);

  const setClause = keys.map((k) => `${k} = @${k}`).join(', ');
  const stmt = db.prepare(`UPDATE config SET ${setClause} WHERE guild_id = @guild_id`);
  stmt.run({ guild_id: guildId, ...updates });

  return getConfig(guildId);
}

function isConfigComplete(guildId) {
  const cfg = getConfig(guildId);
  if (!cfg) return false;
  const required = [
    'orders_channel_id',
    'logs_channel_id',
    'ticket_category_id',
    'admin_role_id',
    'staff_role_id',
  ];
  return required.every((f) => !!cfg[f]);
}

module.exports = { getConfig, setConfig, ensureConfigRow, isConfigComplete, FIELDS };
